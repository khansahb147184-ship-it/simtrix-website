/*
# Create contact_submissions table (single-tenant, no auth)

1. New Tables
- `contact_submissions`
  - `id` (uuid, primary key)
  - `name` (text, not null) — submitter's full name
  - `email` (text, not null) — submitter's email address
  - `phone` (text) — submitter's phone number (optional)
  - `company` (text) — submitter's organisation (optional)
  - `service_interest` (text) — which service/solution they're interested in (optional)
  - `message` (text, not null) — the enquiry body
  - `status` (text, default 'new') — tracking status: new, contacted, closed
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `contact_submissions`.
- Allow anon + authenticated INSERT only (public contact form submissions).
- No SELECT/UPDATE/DELETE for anon — only authenticated (admin) can read/manage.
  This protects submitter privacy while letting the form accept enquiries.

3. Notes
- This is a no-auth public contact form, so INSERT is open to anon.
- Read access is restricted to authenticated (admin) users only.
*/

CREATE TABLE IF NOT EXISTS contact_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  company text,
  service_interest text,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;

-- Allow anyone (anon + authenticated) to submit contact form enquiries
DROP POLICY IF EXISTS "anon_insert_contact" ON contact_submissions;
CREATE POLICY "anon_insert_contact" ON contact_submissions FOR INSERT
TO anon, authenticated WITH CHECK (true);

-- Only authenticated (admin) users can read submissions
DROP POLICY IF EXISTS "auth_select_contact" ON contact_submissions;
CREATE POLICY "auth_select_contact" ON contact_submissions FOR SELECT
TO authenticated USING (true);

-- Only authenticated (admin) users can update submissions (e.g. change status)
DROP POLICY IF EXISTS "auth_update_contact" ON contact_submissions;
CREATE POLICY "auth_update_contact" ON contact_submissions FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

-- Only authenticated (admin) users can delete submissions
DROP POLICY IF EXISTS "auth_delete_contact" ON contact_submissions;
CREATE POLICY "auth_delete_contact" ON contact_submissions FOR DELETE
TO authenticated USING (true);

-- Index for sorting by newest first
CREATE INDEX IF NOT EXISTS idx_contact_submissions_created_at ON contact_submissions (created_at DESC);
