import { Hero } from './home/Hero';
import { EcosystemShowcase } from './home/EcosystemShowcase';
import { SystemIntegration } from './home/SystemIntegration';
import { WhyChooseStats } from './home/WhyChooseStats';
import { ServicesOverview } from './home/ServicesOverview';
import { ImpactBand } from './home/ImpactBand';
import { WhyChooseUs } from './home/WhyChooseUs';
import { Process } from './home/Process';
import { IndustriesShowcase } from './home/IndustriesShowcase';
import { ProjectsPreview } from './home/ProjectsPreview';
import { Testimonials } from './home/Testimonials';
import { CTASection } from '@/components/ui/CTASection';

export function HomePage() {
  return (
    <>
      <Hero />
      <EcosystemShowcase />
      <SystemIntegration />
      <WhyChooseStats />
      <ServicesOverview />
      <ImpactBand />
      <WhyChooseUs />
      <Process />
      <IndustriesShowcase />
      <ProjectsPreview />
      <Testimonials />
      <CTASection />
    </>
  );
}
