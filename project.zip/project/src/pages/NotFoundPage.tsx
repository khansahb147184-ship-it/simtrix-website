import { Link } from 'react-router-dom';
import { ArrowLeft, Home, Wrench } from 'lucide-react';
import { Reveal } from '@/components/ui/Reveal';

export function NotFoundPage() {
  return (
    <section className="relative flex min-h-[70vh] items-center overflow-hidden bg-ink-950 pt-20">
      <div className="absolute inset-0 grid-bg-dark opacity-40" />
      <div className="absolute -top-32 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-brand-600/20 blur-3xl" />

      <div className="container-page relative text-center">
        <Reveal>
          <span className="flex h-20 w-20 mx-auto items-center justify-center rounded-2xl bg-white/5 text-brand-300 ring-1 ring-white/10 backdrop-blur">
            <Wrench className="h-10 w-10" />
          </span>
        </Reveal>
        <Reveal delay={80}>
          <h1 className="mt-8 font-display text-6xl font-bold text-white sm:text-7xl">404</h1>
        </Reveal>
        <Reveal delay={160}>
          <p className="mx-auto mt-4 max-w-md text-lg text-ink-300">
            The page you're looking for isn't here. It may have been moved or never existed.
          </p>
        </Reveal>
        <Reveal delay={240}>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/" className="btn-primary group">
              <Home className="h-4 w-4" />
              Back to Home
            </Link>
            <Link to="/services" className="btn-light">
              <ArrowLeft className="h-4 w-4" />
              Browse Services
            </Link>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
