import { Link } from 'react-router-dom';
import { ArrowRight, Check, Building2, Factory, Zap, ShieldCheck, Server, Layers } from 'lucide-react';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { CTASection } from '@/components/ui/CTASection';

const solutions = [
  {
    icon: Building2,
    title: 'Smart Buildings',
    description: 'Unified BMS, IBMS and building automation that optimise comfort, energy and operations across commercial and residential properties.',
    features: ['BMS & IBMS integration', 'HVAC & lighting automation', 'Energy analytics', 'Cloud monitoring'],
    image: 'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    icon: Factory,
    title: 'Industrial Automation',
    description: 'PLC, SCADA and IIoT systems that improve throughput, quality and safety across manufacturing and process plants.',
    features: ['PLC programming & panels', 'SCADA visualisation', 'Industrial IoT', 'Predictive maintenance'],
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    icon: Zap,
    title: 'Energy Management',
    description: 'Data-driven energy intelligence that benchmarks performance, identifies waste and drives sustained savings.',
    features: ['Multi-utility metering', 'Real-time analytics', 'Benchmarking & KPIs', 'ISO 50001 support'],
    image: 'https://images.pexels.com/photos/433308/pexels-photo-433308.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    icon: ShieldCheck,
    title: 'Security & Surveillance',
    description: 'Integrated CCTV, access control, fire alarm and video analytics that protect people, property and assets.',
    features: ['IP CCTV & VMS', 'AI video analytics', 'Access & visitor management', 'Fire & life safety'],
    image: 'https://images.pexels.com/photos/430208/pexels-photo-430208.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    icon: Server,
    title: 'IT Infrastructure',
    description: 'Resilient networking, structured cabling, data centres and server rooms engineered for mission-critical uptime.',
    features: ['Enterprise networking', 'Structured cabling', 'Data centre build', 'DCIM monitoring'],
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    icon: Layers,
    title: 'ELV & Smart Systems',
    description: 'Extra-low-voltage integration, home automation and Industrial IoT connecting buildings, assets and people.',
    features: ['ELV system integration', 'Home automation', 'Industrial IoT', 'Remote monitoring'],
    image: 'https://images.pexels.com/photos/39284/macbook-apple-laptop-computer-39284.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
];

export function SolutionsPage() {
  return (
    <>
      <PageHero
        eyebrow="Solutions"
        title={<>Integrated solutions for every environment</>}
        subtitle="We combine individual services into cohesive solutions tailored to your facility, your operations and your outcomes — delivered by one accountable engineering team."
        breadcrumbs={[{ label: 'Solutions' }]}
      />

      <Section className="bg-white">
        <SectionContainer>
          <div className="grid gap-8 lg:grid-cols-2">
            {solutions.map((sol, i) => (
              <Reveal key={sol.title} delay={i * 80}>
                <div className="group flex h-full flex-col overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-card transition-all duration-500 hover:-translate-y-1 hover:shadow-card-hover">
                  <div className="relative h-52 overflow-hidden">
                    <img
                      src={sol.image}
                      alt={sol.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent" />
                    <span className="absolute left-5 top-5 flex h-12 w-12 items-center justify-center rounded-xl bg-white/15 text-white ring-1 ring-white/20 backdrop-blur">
                      <sol.icon className="h-6 w-6" />
                    </span>
                    <h3 className="absolute bottom-5 left-5 font-display text-xl font-bold text-white">{sol.title}</h3>
                  </div>
                  <div className="flex flex-1 flex-col p-7">
                    <p className="text-sm leading-relaxed text-ink-500">{sol.description}</p>
                    <ul className="mt-5 grid grid-cols-2 gap-2.5">
                      {sol.features.map((f) => (
                        <li key={f} className="flex items-start gap-2 text-sm text-ink-600">
                          <Check className="mt-0.5 h-4 w-4 shrink-0 text-success-500" />
                          {f}
                        </li>
                      ))}
                    </ul>
                    <Link to="/contact" className="link-underline mt-6">
                      Discuss this solution <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      <CTASection
        title="Not sure which solution fits?"
        subtitle="Tell us about your facility and goals — we'll recommend the right combination of services and systems."
        primaryLabel="Get a Recommendation"
      />
    </>
  );
}
