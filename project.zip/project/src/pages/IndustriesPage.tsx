import { Check } from 'lucide-react';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { CTASection } from '@/components/ui/CTASection';
import { industries } from '@/data/content';

export function IndustriesPage() {
  return (
    <>
      <PageHero
        eyebrow="Industries"
        title={<>Sector-specific engineering, built to perform</>}
        subtitle="Every industry has its own demands — regulatory, operational, environmental. We tailor our smart building and automation solutions to fit the realities of each sector we serve."
        breadcrumbs={[{ label: 'Industries' }]}
      />

      <Section className="bg-white">
        <SectionContainer>
          <div className="grid gap-8 md:grid-cols-2">
            {industries.map((ind, i) => (
              <Reveal key={ind.id} delay={i * 70}>
                <div className="group flex h-full flex-col overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-card transition-all duration-500 hover:-translate-y-1 hover:shadow-card-hover sm:flex-row">
                  <div className="relative h-48 overflow-hidden sm:h-auto sm:w-2/5">
                    <img
                      src={ind.image}
                      alt={ind.name}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-950/50 to-transparent sm:bg-gradient-to-r" />
                    <span className="absolute left-4 top-4 flex h-10 w-10 items-center justify-center rounded-xl bg-white/15 text-white ring-1 ring-white/20 backdrop-blur">
                      <ind.icon className="h-5 w-5" />
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col p-6">
                    <h3 className="font-display text-lg font-bold text-ink-900">{ind.name}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-ink-500">{ind.description}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {ind.highlights.map((h) => (
                        <span key={h} className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-2.5 py-1 text-2xs font-medium text-brand-700">
                          <Check className="h-3 w-3" />
                          {h}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      <CTASection
        title="Building in one of these sectors?"
        subtitle="We bring deep, sector-specific engineering experience to every project. Let's discuss yours."
        primaryLabel="Discuss Your Project"
      />
    </>
  );
}
