import { Link } from 'react-router-dom';
import { ArrowRight, Target, Eye, Award, ShieldCheck, Users, TrendingUp, Cpu, Check, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';
import { CTASection } from '@/components/ui/CTASection';
import { Counter } from '@/components/ui/Counter';
import { stats, company } from '@/data/company';
import { certifications } from '@/data/content';
import { timeline, team, awards } from '@/data/company-extra';

const values = [
  { icon: ShieldCheck, title: 'Engineering Integrity', text: 'We engineer every system to perform reliably for the long term — no shortcuts, no compromises.' },
  { icon: Cpu, title: 'Innovation', text: 'We adopt emerging technologies — IIoT, cloud, AI analytics — to deliver future-ready solutions.' },
  { icon: TrendingUp, title: 'Measurable Outcomes', text: 'We design for verifiable energy savings, uptime and operational efficiency — not just installation.' },
  { icon: Users, title: 'Client Partnership', text: 'We work as an extension of your team — from design through to lifetime support.' },
];

const capabilities = [
  'Building Management Systems (BMS / IBMS)',
  'Industrial automation (PLC, SCADA, IIoT)',
  'Energy management & analytics',
  'Fire alarm & life safety systems',
  'Access control & visitor management',
  'CCTV & AI video analytics',
  'Networking & structured cabling',
  'Data centre & server room solutions',
  'ELV system integration',
  'Home & building automation',
  'Cloud & remote monitoring',
  'AMC & preventive maintenance',
];

export function CompanyPage() {
  return (
    <>
      <PageHero
        eyebrow="Company"
        title={<>Engineering smart infrastructure since {company.foundedYear}</>}
        subtitle={company.description}
        breadcrumbs={[{ label: 'Company' }]}
      />

      {/* Stats band with animated counters */}
      <section className="border-b border-ink-100 bg-white">
        <div className="container-page py-14">
          <div className="grid grid-cols-2 gap-8 lg:grid-cols-4">
            {stats.map((s, i) => (
              <Reveal key={s.label} delay={i * 70}>
                <div className="text-center">
                  <div className="font-display text-4xl font-bold text-ink-900 lg:text-5xl">
                    <Counter value={parseInt(s.value)} suffix={s.suffix} />
                  </div>
                  <div className="mt-2 text-sm font-medium uppercase tracking-wider text-ink-500">{s.label}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <Section className="bg-white">
        <SectionContainer>
          <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
            <Reveal>
              <span className="eyebrow">
                <span className="h-px w-6 bg-current opacity-60" />
                Who We Are
              </span>
              <h2 className="section-title mt-4">A focused engineering firm, built on outcomes</h2>
              <div className="mt-5 space-y-4 text-base leading-relaxed text-ink-600">
                <p>
                  Simtrix Infotech India Pvt Ltd is a New Delhi-based engineering and smart building
                  solutions company. We design, integrate and maintain the systems that keep modern
                  buildings and industrial facilities running efficiently, safely and intelligently.
                </p>
                <p>
                  Our team brings together expertise across building automation, industrial control,
                  energy management, life safety, security and IT infrastructure — allowing us to
                  deliver truly integrated solutions under one roof.
                </p>
                <p>
                  We work with property developers, facility managers, manufacturers, healthcare
                  providers, hospitality groups and institutions across India — engineering outcomes
                  that matter: energy saved, incidents avoided, operations simplified.
                </p>
              </div>
              <Link to="/contact" className="btn-primary mt-8">
                Work With Us <ArrowRight className="h-4 w-4" />
              </Link>
            </Reveal>

            <Reveal delay={120}>
              <div className="relative overflow-hidden rounded-3xl">
                <img
                  src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=900&dpr=2"
                  alt="Simtrix engineering team at work"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/40 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6 rounded-2xl bg-white/10 p-5 ring-1 ring-white/20 backdrop-blur">
                  <div className="flex items-center gap-3">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/15 text-white">
                      <Award className="h-6 w-6" />
                    </span>
                    <div>
                      <div className="font-display text-base font-semibold text-white">Engineering Excellence</div>
                      <div className="text-xs text-white/80">Recognised for integrated, future-ready solutions</div>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </SectionContainer>
      </Section>

      {/* Timeline */}
      <Section className="bg-ink-50/50">
        <SectionContainer>
          <SectionHeading
            eyebrow="Our Journey"
            title={<>A decade of engineering milestones</>}
            subtitle="From our founding to today, every milestone has been driven by a commitment to engineering excellence and client outcomes."
          />

          <div className="relative mt-16">
            {/* Vertical line */}
            <div className="absolute left-4 top-0 h-full w-px bg-gradient-to-b from-brand-500 via-brand-300 to-transparent lg:left-1/2" />

            <div className="space-y-12">
              {timeline.map((event, i) => (
                <Reveal key={event.year} delay={i * 80}>
                  <div className={`relative flex items-start gap-6 lg:w-1/2 ${i % 2 === 0 ? 'lg:ml-auto lg:flex-row-reverse lg:pl-12' : 'lg:pr-12'}`}>
                    {/* Dot */}
                    <div className="absolute left-4 top-1.5 z-10 flex h-4 w-4 -translate-x-1/2 items-center justify-center rounded-full bg-brand-600 ring-4 ring-white lg:left-auto lg:right-auto lg:translate-x-0" style={i % 2 === 0 ? { right: '-0.5rem' } : { left: '-0.5rem' }}>
                      <div className="h-2 w-2 rounded-full bg-white" />
                    </div>

                    {/* Content */}
                    <div className="ml-8 flex-1 rounded-2xl border border-ink-100 bg-white p-6 shadow-card lg:ml-0">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-brand-600" />
                        <span className="font-display text-2xl font-bold text-brand-600">{event.year}</span>
                      </div>
                      <h3 className="mt-3 font-display text-lg font-semibold text-ink-900">{event.title}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-ink-500">{event.description}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </SectionContainer>
      </Section>

      {/* Mission / Vision */}
      <Section className="bg-white">
        <SectionContainer>
          <div className="grid gap-6 md:grid-cols-2">
            {[
              { icon: Target, title: 'Our Mission', text: 'To engineer smart, efficient and safe built environments through integrated automation and intelligent infrastructure.' },
              { icon: Eye, title: 'Our Vision', text: "To be India's most trusted partner for building automation and smart infrastructure — recognised for engineering excellence and innovation." },
            ].map((p, i) => (
              <Reveal key={p.title} delay={i * 80}>
                <div className="h-full rounded-3xl border border-ink-100 bg-white p-8 shadow-card">
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-lg shadow-brand-600/25">
                    <p.icon className="h-7 w-7" />
                  </span>
                  <h3 className="mt-6 font-display text-2xl font-bold text-ink-900">{p.title}</h3>
                  <p className="mt-3 text-base leading-relaxed text-ink-600">{p.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      {/* Values */}
      <Section className="bg-ink-50/50">
        <SectionContainer>
          <SectionHeading
            eyebrow="Our Values"
            title={<>The principles that guide every project</>}
            subtitle="These values shape how we engineer, how we collaborate and how we deliver."
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={i * 80}>
                <div className="group h-full rounded-2xl border border-ink-100 bg-white p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition-all group-hover:bg-brand-600 group-hover:text-white">
                    <v.icon className="h-6 w-6" />
                  </span>
                  <h3 className="mt-5 font-display text-base font-semibold text-ink-900">{v.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-500">{v.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      {/* Team */}
      <Section className="bg-white">
        <SectionContainer>
          <SectionHeading
            eyebrow="Our Team"
            title={<>The people behind the engineering</>}
            subtitle="A multidisciplinary team of engineers, integrators and project managers — each a specialist in their field."
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((member, i) => (
              <Reveal key={member.name} delay={i * 80}>
                <div className="group h-full overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
                  <div className="relative h-56 overflow-hidden">
                    <img
                      src={member.image}
                      alt={`${member.name} - ${member.role}`}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent" />
                  </div>
                  <div className="p-5">
                    <h3 className="font-display text-base font-semibold text-ink-900">{member.name}</h3>
                    <p className="text-sm font-medium text-brand-600">{member.role}</p>
                    <p className="mt-2 text-xs leading-relaxed text-ink-500">{member.bio}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      {/* Awards */}
      <Section className="bg-ink-50/50">
        <SectionContainer>
          <SectionHeading
            eyebrow="Awards & Recognition"
            title={<>Recognised for engineering excellence</>}
            subtitle="Our work has been recognised across the industry for innovation, integration quality and measurable outcomes."
          />
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {awards.map((award, i) => (
              <Reveal key={award.title} delay={i * 80}>
                <div className="h-full rounded-2xl border border-ink-100 bg-white p-6 shadow-card">
                  <div className="flex items-center gap-3">
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-accent-400 to-accent-600 text-white shadow-lg shadow-accent-500/25">
                      <Award className="h-6 w-6" />
                    </span>
                    <span className="font-display text-2xl font-bold text-ink-300">{award.year}</span>
                  </div>
                  <h3 className="mt-4 font-display text-base font-semibold text-ink-900">{award.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-500">{award.description}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      {/* Capabilities */}
      <Section className="bg-white">
        <SectionContainer>
          <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
            <Reveal>
              <span className="eyebrow">
                <span className="h-px w-6 bg-current opacity-60" />
                Capabilities
              </span>
              <h2 className="section-title mt-4">One team. Full-stack engineering.</h2>
              <p className="section-subtitle">
                We cover the full spectrum of building and industrial systems — so you deal with one
                accountable partner instead of a dozen vendors.
              </p>
            </Reveal>
            <Reveal delay={120}>
              <div className="grid gap-3 sm:grid-cols-2">
                {capabilities.map((c) => (
                  <div key={c} className="flex items-start gap-2.5 rounded-xl border border-ink-100 bg-white p-4">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-success-500" />
                    <span className="text-sm font-medium text-ink-700">{c}</span>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </SectionContainer>
      </Section>

      {/* Certifications */}
      <Section className="bg-ink-50/50 pt-0">
        <SectionContainer>
          <Reveal>
            <p className="text-center text-xs font-semibold uppercase tracking-[0.2em] text-ink-500">
              Certifications & Standards
            </p>
          </Reveal>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            {certifications.map((c, i) => (
              <Reveal key={c} delay={i * 60}>
                <span className="flex items-center gap-2 rounded-full border border-ink-200 bg-white px-5 py-2.5 text-sm font-semibold text-ink-700">
                  <ShieldCheck className="h-4 w-4 text-success-600" />
                  {c}
                </span>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      <CTASection />
    </>
  );
}
