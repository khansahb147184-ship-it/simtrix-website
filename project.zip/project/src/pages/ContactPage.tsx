import { useState, type FormEvent } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { company, contactItems } from '@/data/company';
import { serviceGroups } from '@/data/services';
import { supabase } from '@/lib/supabase';

type FormState = {
  name: string;
  email: string;
  phone: string;
  company: string;
  service_interest: string;
  message: string;
};

const initialForm: FormState = {
  name: '',
  email: '',
  phone: '',
  company: '',
  service_interest: '',
  message: '',
};

export function ContactPage() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const allServiceOptions = serviceGroups.flatMap((g) =>
    g.services.map((s) => ({ label: s.name, value: s.name })),
  );

  const handleChange = (field: keyof FormState, value: string) => {
    setForm((f) => ({ ...f, [field]: value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    setErrorMsg('');

    try {
      const { error } = await supabase.from('contact_submissions').insert({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || null,
        company: form.company.trim() || null,
        service_interest: form.service_interest || null,
        message: form.message.trim(),
      });

      if (error) throw error;

      setStatus('success');
      setForm(initialForm);
    } catch (err: any) {
      setStatus('error');
      setErrorMsg(err?.message ?? 'Something went wrong. Please try again or call us directly.');
    }
  };

  return (
    <>
      <PageHero
        eyebrow="Contact"
        title={<>Let's build something smart together</>}
        subtitle="Tell us about your project, your facility or your goals. Our engineering team will get back to you within one business day."
        breadcrumbs={[{ label: 'Contact' }]}
      />

      <Section className="bg-white">
        <SectionContainer>
          <div className="grid gap-12 lg:grid-cols-5">
            {/* Contact info */}
            <div className="lg:col-span-2">
              <Reveal>
                <span className="eyebrow">
                  <span className="h-px w-6 bg-current opacity-60" />
                  Get in Touch
                </span>
                <h2 className="section-title mt-4 !text-2xl sm:!text-3xl">We're here to help</h2>
                <p className="mt-4 text-base leading-relaxed text-ink-500">
                  Reach out by phone, email or the form — whatever suits you. We respond to all
                  enquiries within one business day.
                </p>
              </Reveal>

              <div className="mt-10 space-y-4">
                {contactItems.map((item, i) => {
                  const content = (
                    <div className="group flex items-start gap-4 rounded-2xl border border-ink-100 bg-white p-5 transition-all hover:border-brand-200 hover:shadow-card">
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition-colors group-hover:bg-brand-600 group-hover:text-white">
                        <item.icon className="h-5 w-5" />
                      </span>
                      <div>
                        <div className="text-xs font-semibold uppercase tracking-wider text-ink-400">{item.label}</div>
                        <div className="mt-1 text-sm font-semibold text-ink-800">{item.value}</div>
                      </div>
                    </div>
                  );
                  return (
                    <Reveal key={item.label} delay={i * 70}>
                      {item.href ? (
                        <a href={item.href} className="block">{content}</a>
                      ) : (
                        content
                      )}
                    </Reveal>
                  );
                })}
              </div>

              {/* Address card */}
              <Reveal delay={280}>
                <div className="mt-4 rounded-2xl border border-ink-100 bg-ink-50/50 p-5">
                  <div className="flex items-start gap-3">
                    <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
                    <div className="text-sm leading-relaxed text-ink-600">
                      <strong className="text-ink-900">{company.name}</strong>
                      <br />
                      {company.address.line1}, {company.address.line2}
                      <br />
                      {company.address.line3}, {company.address.line4}
                      <br />
                      {company.address.city}, {company.address.state} - {company.address.pincode}
                      <br />
                      {company.address.country}
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>

            {/* Form */}
            <div className="lg:col-span-3">
              <Reveal delay={120}>
                <form
                  onSubmit={handleSubmit}
                  className="rounded-3xl border border-ink-100 bg-white p-8 shadow-card lg:p-10"
                >
                  {status === 'success' && (
                    <div className="mb-6 flex items-start gap-3 rounded-xl border border-success-200 bg-success-50 p-4">
                      <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-success-600" />
                      <div>
                        <p className="text-sm font-semibold text-success-800">Message sent successfully!</p>
                        <p className="mt-1 text-sm text-success-700">
                          Thank you for reaching out. Our team will respond within one business day.
                        </p>
                      </div>
                    </div>
                  )}

                  {status === 'error' && (
                    <div className="mb-6 flex items-start gap-3 rounded-xl border border-error-200 bg-error-50 p-4">
                      <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-error-600" />
                      <div>
                        <p className="text-sm font-semibold text-error-800">Could not send your message.</p>
                        <p className="mt-1 text-sm text-error-700">{errorMsg}</p>
                      </div>
                    </div>
                  )}

                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="Full Name" required>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={(e) => handleChange('name', e.target.value)}
                        placeholder="Your name"
                        className="form-input"
                      />
                    </Field>
                    <Field label="Email" required>
                      <input
                        type="email"
                        required
                        value={form.email}
                        onChange={(e) => handleChange('email', e.target.value)}
                        placeholder="you@company.com"
                        className="form-input"
                      />
                    </Field>
                    <Field label="Phone">
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => handleChange('phone', e.target.value)}
                        placeholder="+91 ..."
                        className="form-input"
                      />
                    </Field>
                    <Field label="Company / Organisation">
                      <input
                        type="text"
                        value={form.company}
                        onChange={(e) => handleChange('company', e.target.value)}
                        placeholder="Your company"
                        className="form-input"
                      />
                    </Field>
                  </div>

                  <div className="mt-5">
                    <Field label="Service of Interest">
                      <select
                        value={form.service_interest}
                        onChange={(e) => handleChange('service_interest', e.target.value)}
                        className="form-input"
                      >
                        <option value="">Select a service (optional)</option>
                        {allServiceOptions.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </Field>
                  </div>

                  <div className="mt-5">
                    <Field label="Message" required>
                      <textarea
                        required
                        rows={5}
                        value={form.message}
                        onChange={(e) => handleChange('message', e.target.value)}
                        placeholder="Tell us about your project, facility or requirements..."
                        className="form-input resize-none"
                      />
                    </Field>
                  </div>

                  <button
                    type="submit"
                    disabled={status === 'submitting'}
                    className="btn-primary mt-8 w-full disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {status === 'submitting' ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        Send Message
                        <Send className="h-4 w-4" />
                      </>
                    )}
                  </button>

                  <p className="mt-4 text-center text-xs text-ink-400">
                    By submitting, you agree to be contacted by Simtrix Infotech regarding your enquiry.
                  </p>
                </form>
              </Reveal>
            </div>
          </div>
        </SectionContainer>
      </Section>

      {/* Emergency support + Google Map */}
      <section className="bg-ink-950 py-16">
        <SectionContainer>
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Emergency support */}
            <Reveal>
              <div className="h-full rounded-2xl border border-error-500/30 bg-error-500/10 p-6">
                <div className="flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-error-500/20 text-error-400">
                    <Phone className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="font-display text-base font-semibold text-white">Emergency Support</h3>
                    <p className="text-xs text-ink-400">24/7 for AMC clients</p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-ink-300">
                  Existing AMC clients can reach our emergency support line for critical system
                  failures — any time, day or night.
                </p>
                <a href={company.phoneHref} className="btn-primary mt-5 w-full">
                  <Phone className="h-4 w-4" />
                  {company.phone}
                </a>
              </div>
            </Reveal>

            {/* Business hours */}
            <Reveal delay={80}>
              <div className="h-full rounded-2xl border border-white/10 bg-white/5 p-6">
                <div className="flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-500/20 text-brand-300">
                    <Clock className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="font-display text-base font-semibold text-white">Business Hours</h3>
                    <p className="text-xs text-ink-400">Office operations</p>
                  </div>
                </div>
                <div className="mt-4 space-y-2 text-sm">
                  <div className="flex justify-between text-ink-300">
                    <span>Monday - Friday</span>
                    <span className="font-semibold text-white">9:30 AM - 6:30 PM</span>
                  </div>
                  <div className="flex justify-between text-ink-300">
                    <span>Saturday</span>
                    <span className="font-semibold text-white">9:30 AM - 2:00 PM</span>
                  </div>
                  <div className="flex justify-between text-ink-300">
                    <span>Sunday</span>
                    <span className="font-semibold text-error-400">Closed</span>
                  </div>
                </div>
              </div>
            </Reveal>

            {/* Quick contact */}
            <Reveal delay={160}>
              <div className="h-full rounded-2xl border border-white/10 bg-white/5 p-6">
                <div className="flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-success-500/20 text-success-300">
                    <Mail className="h-5 w-5" />
                  </span>
                  <div>
                    <h3 className="font-display text-base font-semibold text-white">Quick Contact</h3>
                    <p className="text-xs text-ink-400">Reach us directly</p>
                  </div>
                </div>
                <div className="mt-4 space-y-3 text-sm">
                  <a href={company.phoneHref} className="flex items-center gap-2 text-ink-300 transition-colors hover:text-white">
                    <Phone className="h-4 w-4 text-brand-400" /> {company.phone}
                  </a>
                  <a href={company.emailHref} className="flex items-center gap-2 text-ink-300 transition-colors hover:text-white">
                    <Mail className="h-4 w-4 text-brand-400" /> {company.email}
                  </a>
                  <p className="flex items-start gap-2 text-ink-300">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                    <span>{company.address.line4}, {company.address.city} - {company.address.pincode}</span>
                  </p>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Google Map embed */}
          <Reveal delay={200}>
            <div className="mt-6 overflow-hidden rounded-2xl border border-white/10">
              <iframe
                title="Simtrix Infotech Office Location"
                src={`https://www.google.com/maps?q=${encodeURIComponent(
                  `${company.address.line4}, ${company.address.city}, ${company.address.state} ${company.address.pincode}`,
                )}&output=embed`}
                width="100%"
                height="320"
                style={{ border: 0, filter: 'grayscale(0.3) invert(0.9) hue-rotate(180deg)' }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </Reveal>
        </SectionContainer>
      </section>
    </>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-semibold text-ink-700">
        {label}
        {required && <span className="text-error-500"> *</span>}
      </span>
      {children}
    </label>
  );
}
