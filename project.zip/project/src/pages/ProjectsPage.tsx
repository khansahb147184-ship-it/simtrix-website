import { useState } from 'react';
import { MapPin, Calendar, ArrowRight, CheckCircle2, Clock, Zap, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { CTASection } from '@/components/ui/CTASection';
import { projects, type Project } from '@/data/content';

const categories = ['All', ...Array.from(new Set(projects.map((p) => p.category)))];

const statusConfig: Record<string, { icon: typeof CheckCircle2; color: string; bg: string }> = {
  Completed: { icon: CheckCircle2, color: 'text-success-700', bg: 'bg-success-50' },
  Ongoing: { icon: Clock, color: 'text-warning-700', bg: 'bg-warning-50' },
  Commissioned: { icon: Zap, color: 'text-brand-700', bg: 'bg-brand-50' },
};

export function ProjectsPage() {
  const [filter, setFilter] = useState('All');
  const [selected, setSelected] = useState<Project | null>(null);

  const filtered = filter === 'All' ? projects : projects.filter((p) => p.category === filter);

  return (
    <>
      <PageHero
        eyebrow="Projects"
        title={<>Delivered work that speaks for itself</>}
        subtitle="A portfolio of real projects across manufacturing, commercial, healthcare, retail, airports and more — each engineered, integrated and delivered by our team."
        breadcrumbs={[{ label: 'Projects' }]}
      />

      <Section className="bg-white">
        <SectionContainer>
          {/* Filter */}
          <Reveal>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition-all ${
                    filter === cat
                      ? 'bg-brand-600 text-white shadow-lg shadow-brand-600/25'
                      : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </Reveal>

          <div className="mt-12 grid gap-8 lg:grid-cols-2">
            {filtered.map((p, i) => {
              const status = statusConfig[p.status] ?? statusConfig.Completed;
              const StatusIcon = status.icon;

              return (
                <Reveal key={p.id} delay={i * 70}>
                  <article className="group flex h-full flex-col overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-card transition-all duration-500 hover:-translate-y-1 hover:shadow-card-hover">
                    <div className="relative h-64 overflow-hidden">
                      <img
                        src={p.image}
                        alt={`${p.title} - ${p.location}`}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-ink-950/10 to-transparent" />
                      <span className="absolute left-5 top-5 rounded-full bg-white/15 px-3 py-1 text-2xs font-semibold uppercase tracking-wider text-white ring-1 ring-white/20 backdrop-blur">
                        {p.category}
                      </span>
                      <span className={`absolute right-5 top-5 inline-flex items-center gap-1.5 rounded-full ${status.bg} px-3 py-1 text-2xs font-semibold ${status.color}`}>
                        <StatusIcon className="h-3.5 w-3.5" />
                        {p.status}
                      </span>
                      <div className="absolute bottom-5 left-5 right-5 flex items-center justify-between text-xs text-white/90">
                        <span className="flex items-center gap-1.5">
                          <MapPin className="h-3.5 w-3.5" /> {p.location}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Calendar className="h-3.5 w-3.5" /> {p.year}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-1 flex-col p-7">
                      <span className="text-xs font-semibold uppercase tracking-wider text-brand-600">{p.industry}</span>
                      <h3 className="mt-2 font-display text-xl font-bold text-ink-900">{p.title}</h3>
                      <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-ink-500">{p.description}</p>

                      {/* Technology tags */}
                      <div className="mt-4 flex flex-wrap gap-1.5">
                        {p.technology.slice(0, 4).map((tech) => (
                          <span key={tech} className="rounded-full bg-brand-50 px-2.5 py-1 text-2xs font-medium text-brand-700">
                            {tech}
                          </span>
                        ))}
                      </div>

                      {/* Scope */}
                      <div className="mt-4 flex flex-wrap gap-1.5">
                        {p.scope.slice(0, 3).map((s) => (
                          <span key={s} className="rounded-full bg-ink-50 px-2.5 py-1 text-2xs font-medium text-ink-600">
                            {s}
                          </span>
                        ))}
                      </div>

                      <div className="mt-6 flex items-center gap-3 border-t border-ink-100 pt-5">
                        <button
                          onClick={() => setSelected(p)}
                          className="btn-primary group/btn flex-1"
                        >
                          Case Study
                          <ArrowRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                        </button>
                      </div>
                    </div>
                  </article>
                </Reveal>
              );
            })}
          </div>
        </SectionContainer>
      </Section>

      {/* Case study modal */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelected(null)}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-3xl bg-white shadow-2xl"
            >
              <button
                onClick={() => setSelected(null)}
                className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-ink-100 text-ink-600 transition-colors hover:bg-ink-200"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="relative h-64 overflow-hidden rounded-t-3xl">
                <img src={selected.image} alt={selected.title} className="h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 to-transparent" />
                <div className="absolute bottom-5 left-7">
                  <span className="text-xs font-semibold uppercase tracking-wider text-brand-300">{selected.industry}</span>
                  <h2 className="mt-1 font-display text-2xl font-bold text-white">{selected.title}</h2>
                </div>
              </div>

              <div className="p-7">
                {/* Meta info */}
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                  <div>
                    <div className="text-2xs font-medium uppercase tracking-wider text-ink-400">Location</div>
                    <div className="mt-1 text-sm font-semibold text-ink-800">{selected.location}</div>
                  </div>
                  <div>
                    <div className="text-2xs font-medium uppercase tracking-wider text-ink-400">Year</div>
                    <div className="mt-1 text-sm font-semibold text-ink-800">{selected.year}</div>
                  </div>
                  <div>
                    <div className="text-2xs font-medium uppercase tracking-wider text-ink-400">Client</div>
                    <div className="mt-1 text-sm font-semibold text-ink-800">{selected.client}</div>
                  </div>
                  <div>
                    <div className="text-2xs font-medium uppercase tracking-wider text-ink-400">Status</div>
                    <div className="mt-1 text-sm font-semibold text-success-700">{selected.status}</div>
                  </div>
                </div>

                <p className="mt-6 text-base leading-relaxed text-ink-600">{selected.description}</p>

                {/* Technology */}
                <h3 className="mt-8 font-display text-lg font-semibold text-ink-900">Technology Used</h3>
                <div className="mt-4 flex flex-wrap gap-2">
                  {selected.technology.map((tech) => (
                    <span key={tech} className="rounded-full bg-brand-50 px-3 py-1.5 text-sm font-medium text-brand-700">
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Scope */}
                <h3 className="mt-8 font-display text-lg font-semibold text-ink-900">Scope of Work</h3>
                <div className="mt-4 flex flex-wrap gap-2">
                  {selected.scope.map((s) => (
                    <span key={s} className="rounded-full bg-ink-50 px-3 py-1.5 text-sm font-medium text-ink-600">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <CTASection
        title="Your project could be next"
        subtitle="From concept to commissioning, we deliver projects that perform. Let's start yours."
        primaryLabel="Start a Project"
      />
    </>
  );
}
