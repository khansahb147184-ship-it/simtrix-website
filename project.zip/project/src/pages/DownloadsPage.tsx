import { useState } from 'react';
import { Download, FileText, Building2, Boxes, Cpu, Monitor, Camera, Lock, Flame } from 'lucide-react';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { CTASection } from '@/components/ui/CTASection';
import { downloads, downloadCategories } from '@/data/downloads';

const iconMap: Record<string, typeof FileText> = {
  FileText, Building2, Boxes, Cpu, Monitor, Camera, Lock, Flame,
};

export function DownloadsPage() {
  const [filter, setFilter] = useState<string>('All');
  const filtered = filter === 'All' ? downloads : downloads.filter((d) => d.category === filter);

  return (
    <>
      <PageHero
        eyebrow="Downloads"
        title={<>Brochures, catalogues & datasheets</>}
        subtitle="Access our complete library of company brochures, product catalogues and technical datasheets — all available for instant download."
        breadcrumbs={[{ label: 'Downloads' }]}
      />

      <Section className="bg-white">
        <SectionContainer>
          {/* Filter */}
          <Reveal>
            <div className="flex flex-wrap gap-2">
              {downloadCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition-all ${
                    filter === cat
                      ? 'bg-brand-600 text-white shadow-lg shadow-brand-600/25'
                      : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </Reveal>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((item, i) => {
              const Icon = iconMap[item.icon] ?? FileText;
              return (
                <Reveal key={item.id} delay={i * 70}>
                  <div className="group flex h-full flex-col rounded-2xl border border-ink-100 bg-white p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-card-hover">
                    <div className="flex items-start justify-between">
                      <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition-all group-hover:bg-brand-600 group-hover:text-white">
                        <Icon className="h-6 w-6" />
                      </span>
                      <span className="rounded-full bg-ink-50 px-2.5 py-1 text-2xs font-semibold uppercase tracking-wider text-ink-500">
                        {item.fileType} - {item.fileSize}
                      </span>
                    </div>

                    <h3 className="mt-5 font-display text-base font-semibold text-ink-900">{item.title}</h3>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-500">{item.description}</p>

                    <div className="mt-5 flex items-center justify-between border-t border-ink-100 pt-4">
                      <span className="text-xs font-medium text-ink-400">{item.category}</span>
                      <a
                        href={item.url}
                        className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-600 transition-colors hover:text-brand-700"
                      >
                        <Download className="h-4 w-4" />
                        Download
                      </a>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </SectionContainer>
      </Section>

      <CTASection
        title="Need a custom datasheet?"
        subtitle="Contact our team for product specifications tailored to your project requirements."
        primaryLabel="Request Information"
      />
    </>
  );
}
