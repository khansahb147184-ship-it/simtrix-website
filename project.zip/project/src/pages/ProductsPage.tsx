import { useState } from 'react';
import { Download, FileText, Check, ArrowRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { CTASection } from '@/components/ui/CTASection';
import { products, productCategories, type Product } from '@/data/products';

export function ProductsPage() {
  const [filter, setFilter] = useState('All');
  const [selected, setSelected] = useState<Product | null>(null);

  const filtered = filter === 'All' ? products : products.filter((p) => p.category === filter);

  return (
    <>
      <PageHero
        eyebrow="Products"
        title={<>Enterprise product catalogue</>}
        subtitle="Professional-grade controllers, panels, cameras and access systems — with full specifications, features, applications and downloadable datasheets."
        breadcrumbs={[{ label: 'Products' }]}
      />

      <Section className="bg-white">
        <SectionContainer>
          {/* Filter */}
          <Reveal>
            <div className="flex flex-wrap gap-2">
              {productCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition-all ${
                    filter === cat
                      ? 'bg-brand-600 text-white shadow-lg shadow-brand-600/25'
                      : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </Reveal>

          <div className="mt-12 grid gap-8 lg:grid-cols-2">
            {filtered.map((product, i) => (
              <Reveal key={product.id} delay={i * 80}>
                <div className="group flex h-full flex-col overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-card transition-all duration-500 hover:-translate-y-1 hover:shadow-card-hover">
                  <div className="relative h-56 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-950/60 to-transparent" />
                    <span className="absolute left-5 top-5 rounded-full bg-white/15 px-3 py-1 text-2xs font-semibold uppercase tracking-wider text-white ring-1 ring-white/20 backdrop-blur">
                      {product.category}
                    </span>
                  </div>

                  <div className="flex flex-1 flex-col p-7">
                    <h3 className="font-display text-xl font-bold text-ink-900">{product.name}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-ink-500">{product.description}</p>

                    {/* Key specs */}
                    <div className="mt-5 grid grid-cols-2 gap-2">
                      {product.specifications.slice(0, 4).map((spec) => (
                        <div key={spec.label} className="rounded-lg bg-ink-50/60 px-3 py-2">
                          <div className="text-2xs font-medium uppercase tracking-wider text-ink-400">{spec.label}</div>
                          <div className="text-sm font-semibold text-ink-800">{spec.value}</div>
                        </div>
                      ))}
                    </div>

                    {/* Features */}
                    <ul className="mt-5 space-y-1.5">
                      {product.features.slice(0, 3).map((f) => (
                        <li key={f} className="flex items-start gap-2 text-sm text-ink-600">
                          <Check className="mt-0.5 h-4 w-4 shrink-0 text-success-500" />
                          {f}
                        </li>
                      ))}
                    </ul>

                    {/* Actions */}
                    <div className="mt-6 flex flex-wrap gap-3 border-t border-ink-100 pt-5">
                      <button
                        onClick={() => setSelected(product)}
                        className="btn-primary group"
                      >
                        View Details
                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </button>
                      <a href={product.datasheetUrl} className="btn-outline">
                        <FileText className="h-4 w-4" />
                        Datasheet
                      </a>
                      <a href={product.brochureUrl} className="btn-outline">
                        <Download className="h-4 w-4" />
                        Brochure
                      </a>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      {/* Product detail modal */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelected(null)}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-ink-950/60 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              transition={{ duration: 0.3 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-3xl bg-white shadow-2xl"
            >
              <button
                onClick={() => setSelected(null)}
                className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-ink-100 text-ink-600 transition-colors hover:bg-ink-200"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="relative h-64 overflow-hidden rounded-t-3xl">
                <img src={selected.image} alt={selected.name} className="h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 to-transparent" />
                <div className="absolute bottom-5 left-7">
                  <span className="rounded-full bg-white/15 px-3 py-1 text-2xs font-semibold uppercase tracking-wider text-white ring-1 ring-white/20 backdrop-blur">
                    {selected.category}
                  </span>
                  <h2 className="mt-2 font-display text-2xl font-bold text-white">{selected.name}</h2>
                </div>
              </div>

              <div className="p-7">
                <p className="text-base leading-relaxed text-ink-600">{selected.description}</p>

                <h3 className="mt-8 font-display text-lg font-semibold text-ink-900">Specifications</h3>
                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {selected.specifications.map((spec) => (
                    <div key={spec.label} className="rounded-xl border border-ink-100 bg-ink-50/50 p-4">
                      <div className="text-2xs font-medium uppercase tracking-wider text-ink-400">{spec.label}</div>
                      <div className="mt-1 text-sm font-semibold text-ink-800">{spec.value}</div>
                    </div>
                  ))}
                </div>

                <h3 className="mt-8 font-display text-lg font-semibold text-ink-900">Features</h3>
                <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                  {selected.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-ink-600">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-success-500" />
                      {f}
                    </li>
                  ))}
                </ul>

                <h3 className="mt-8 font-display text-lg font-semibold text-ink-900">Applications</h3>
                <div className="mt-4 flex flex-wrap gap-2">
                  {selected.applications.map((app) => (
                    <span key={app} className="rounded-full bg-brand-50 px-3 py-1.5 text-sm font-medium text-brand-700">
                      {app}
                    </span>
                  ))}
                </div>

                <div className="mt-8 flex flex-wrap gap-3 border-t border-ink-100 pt-6">
                  <a href={selected.datasheetUrl} className="btn-primary">
                    <FileText className="h-4 w-4" />
                    Download Datasheet
                  </a>
                  <a href={selected.brochureUrl} className="btn-outline">
                    <Download className="h-4 w-4" />
                    Download Brochure
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <CTASection />
    </>
  );
}
