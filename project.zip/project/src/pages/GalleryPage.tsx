import { useState } from 'react';
import { Play, X, ZoomIn } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { CTASection } from '@/components/ui/CTASection';
import { galleryItems, galleryCategories, type GalleryItem } from '@/data/gallery';

export function GalleryPage() {
  const [filter, setFilter] = useState<string>('All');
  const [selected, setSelected] = useState<GalleryItem | null>(null);

  const filtered = filter === 'All' ? galleryItems : galleryItems.filter((g) => g.category === filter);

  const spanClass = (span?: string) => {
    switch (span) {
      case 'tall': return 'row-span-2';
      case 'wide': return 'col-span-2';
      default: return '';
    }
  };

  return (
    <>
      <PageHero
        eyebrow="Gallery"
        title={<>Project photos, installations & videos</>}
        subtitle="A visual showcase of our engineering work — from control rooms and plant installations to completed smart building projects across India."
        breadcrumbs={[{ label: 'Gallery' }]}
      />

      <Section className="bg-white">
        <SectionContainer>
          {/* Filter */}
          <Reveal>
            <div className="flex flex-wrap gap-2">
              {galleryCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition-all ${
                    filter === cat
                      ? 'bg-brand-600 text-white shadow-lg shadow-brand-600/25'
                      : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </Reveal>

          {/* Masonry grid */}
          <div className="mt-12 grid auto-rows-[200px] grid-cols-2 gap-4 lg:grid-cols-4">
            {filtered.map((item, i) => (
              <Reveal key={item.id} delay={i * 60} className={spanClass(item.span)}>
                <button
                  onClick={() => setSelected(item)}
                  className="group relative h-full w-full overflow-hidden rounded-2xl border border-ink-100 shadow-card"
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-ink-950/20 to-transparent" />

                  {item.category === 'Videos' && (
                    <span className="absolute left-1/2 top-1/2 flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/20 ring-1 ring-white/30 backdrop-blur transition-all group-hover:scale-110 group-hover:bg-white/30">
                      <Play className="h-6 w-6 fill-white text-white" />
                    </span>
                  )}

                  <span className="absolute left-4 top-4 rounded-full bg-white/15 px-3 py-1 text-2xs font-semibold uppercase tracking-wider text-white ring-1 ring-white/20 backdrop-blur">
                    {item.category}
                  </span>

                  <div className="absolute bottom-0 left-0 right-0 p-4 text-left">
                    <h3 className="font-display text-base font-semibold text-white">{item.title}</h3>
                    <p className="mt-1 line-clamp-1 text-xs text-ink-300">{item.description}</p>
                  </div>

                  <span className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/15 text-white opacity-0 ring-1 ring-white/20 backdrop-blur transition-opacity group-hover:opacity-100">
                    <ZoomIn className="h-4 w-4" />
                  </span>
                </button>
              </Reveal>
            ))}
          </div>
        </SectionContainer>
      </Section>

      {/* Lightbox */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelected(null)}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-ink-950/90 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-h-[90vh] w-full max-w-4xl overflow-hidden rounded-3xl"
            >
              <button
                onClick={() => setSelected(null)}
                className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white ring-1 ring-white/20 backdrop-blur transition-colors hover:bg-white/25"
              >
                <X className="h-5 w-5" />
              </button>
              <img src={selected.image} alt={selected.title} className="max-h-[80vh] w-full object-cover" />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-ink-950 to-transparent p-6">
                <span className="rounded-full bg-white/15 px-3 py-1 text-2xs font-semibold uppercase tracking-wider text-white ring-1 ring-white/20 backdrop-blur">
                  {selected.category}
                </span>
                <h3 className="mt-3 font-display text-xl font-bold text-white">{selected.title}</h3>
                <p className="mt-1 text-sm text-ink-300">{selected.description}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <CTASection />
    </>
  );
}
