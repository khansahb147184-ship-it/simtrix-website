import { clients } from '@/data/content';
import { Reveal } from '@/components/ui/Reveal';

export function ClientLogos() {
  const doubled = [...clients, ...clients];

  return (
    <div className="mt-20">
      <Reveal>
        <p className="text-center text-xs font-semibold uppercase tracking-[0.2em] text-ink-500">
          Trusted by Industry Leaders & Technology Partners
        </p>
      </Reveal>

      {/* Animated logo carousel */}
      <div className="relative mt-10 overflow-hidden mask-fade-edges">
        <div className="flex w-max animate-marquee gap-4">
          {doubled.map((client, i) => (
            <div
              key={i}
              className="group flex h-20 min-w-[140px] items-center justify-center rounded-2xl border border-ink-100 bg-white px-6 shadow-card transition-all duration-300 hover:border-brand-200 hover:shadow-card-hover"
            >
              <span className="font-display text-lg font-bold text-ink-400 transition-colors duration-300 group-hover:text-brand-600">
                {client}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Second row reverse direction */}
      <div className="relative mt-4 overflow-hidden mask-fade-edges">
        <div className="flex w-max animate-marquee-reverse gap-4">
          {doubled.reverse().map((client, i) => (
            <div
              key={i}
              className="group flex h-16 min-w-[120px] items-center justify-center rounded-xl border border-ink-100 bg-ink-50/50 px-5 transition-all duration-300 hover:border-brand-200 hover:bg-white"
            >
              <span className="font-display text-base font-semibold text-ink-400 transition-colors duration-300 group-hover:text-brand-600">
                {client}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
