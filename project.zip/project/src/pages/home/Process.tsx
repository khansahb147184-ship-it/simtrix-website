import { Search, PencilRuler, Cpu, Wrench, BarChart3 } from 'lucide-react';
import { Section, SectionContainer } from '@/components/ui/Section';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';

const steps = [
  { icon: Search, title: 'Discover & Assess', text: 'We study your facility, operations and goals to define the right system architecture and scope.', phase: '01' },
  { icon: PencilRuler, title: 'Design & Engineer', text: 'Detailed engineering, schematics, I/O lists and cause-and-effect logic — reviewed with your team.', phase: '02' },
  { icon: Cpu, title: 'Install & Integrate', text: 'Clean, standards-compliant installation with cross-system integration and open protocols.', phase: '03' },
  { icon: Wrench, title: 'Commission & Handover', text: 'Full commissioning, performance testing, operator training and as-built documentation.', phase: '04' },
  { icon: BarChart3, title: 'Monitor & Maintain', text: 'Remote monitoring, preventive maintenance and AMC support for lifetime performance.', phase: '05' },
];

export function Process() {
  return (
    <Section className="bg-white">
      <SectionContainer>
        <SectionHeading
          eyebrow="How We Work"
          title={<>A proven engineering process — end to end</>}
          subtitle="From first consultation to lifetime support, we follow a disciplined engineering process that de-risks delivery and guarantees outcomes."
        />

        <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-5">
          {steps.map((step, i) => (
            <Reveal key={step.title} delay={i * 80}>
              <div className="group relative h-full rounded-2xl border border-ink-100 bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-card-hover">
                <div className="flex items-center justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-ink-50 text-ink-600 transition-all group-hover:bg-brand-600 group-hover:text-white">
                    <step.icon className="h-6 w-6" />
                  </span>
                  <span className="font-display text-3xl font-bold text-ink-100 transition-colors group-hover:text-brand-100">
                    {step.phase}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-base font-semibold text-ink-900">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">{step.text}</p>

                {/* Connector arrow */}
                {i < steps.length - 1 && (
                  <span className="absolute -right-3 top-1/2 hidden h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full bg-brand-100 text-brand-600 lg:flex">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path d="M2 6h8m0 0L6 2m4 4L6 10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </SectionContainer>
    </Section>
  );
}
