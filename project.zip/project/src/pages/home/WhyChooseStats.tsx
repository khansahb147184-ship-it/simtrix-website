import { motion } from 'framer-motion';
import { whyChooseStats } from '@/data/ecosystem';
import { Reveal } from '@/components/ui/Reveal';

export function WhyChooseStats() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-r from-brand-700 via-brand-800 to-ink-950 py-20 lg:py-24">
      <div className="absolute inset-0 grid-bg-dark opacity-30" />
      <div className="absolute -right-20 -top-20 h-80 w-80 rounded-full bg-white/10 blur-3xl" />
      <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-accent-500/10 blur-3xl" />

      <div className="container-page relative">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow !text-brand-200">
              <span className="h-px w-6 bg-current opacity-60" />
              Why Choose Simtrix
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl lg:text-5xl">
              The engineering partner of choice
            </h2>
            <p className="mt-4 text-lg text-brand-100">
              Trusted by 350+ clients across India for integrated smart building and industrial automation solutions.
            </p>
          </div>
        </Reveal>

        {/* Stats grid */}
        <div className="mt-14 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {whyChooseStats.map((stat, i) => (
            <Reveal key={stat.label} delay={i * 60}>
              <motion.div
                whileHover={{ y: -4 }}
                transition={{ duration: 0.3 }}
                className="group flex h-full flex-col items-center justify-center rounded-2xl border border-white/10 bg-white/5 p-6 text-center backdrop-blur-xl transition-colors hover:border-white/20 hover:bg-white/10"
              >
                <div className="font-display text-3xl font-bold text-white lg:text-4xl">
                  {stat.value}
                  {stat.suffix && (
                    <span className="text-brand-200">{stat.suffix}</span>
                  )}
                </div>
                <div className="mt-2 text-xs font-medium uppercase tracking-wider text-brand-200/80 sm:text-sm">
                  {stat.label}
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
