import { motion } from 'framer-motion';
import { Check, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ecosystemCategories } from '@/data/ecosystem';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';

export function EcosystemShowcase() {
  return (
    <section className="relative overflow-hidden bg-ink-950 py-24 lg:py-32">
      {/* Background layers */}
      <div className="absolute inset-0 grid-bg-dark opacity-40" />
      <div className="absolute inset-0 bg-gradient-to-b from-ink-950 via-ink-950 to-ink-900" />
      <div className="absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-brand-600/15 blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-0 right-1/4 h-80 w-80 rounded-full bg-accent-500/8 blur-3xl animate-pulse-slow" />

      <div className="container-page relative">
        <SectionHeading
          light
          eyebrow="Complete Ecosystem"
          title={
            <>
              Complete Smart Building &{' '}
              <span className="text-gradient-light">Industrial Automation Ecosystem</span>
            </>
          }
          subtitle="Everything required to design, integrate, monitor and maintain intelligent buildings from a single engineering partner."
        />

        {/* Category cards grid */}
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {ecosystemCategories.map((cat, i) => (
            <Reveal key={cat.id} delay={i * 50}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ duration: 0.4, ease: 'easeOut' }}
                className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl"
              >
                {/* Glow on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${cat.accent} opacity-0 transition-opacity duration-500 group-hover:opacity-10`} />

                {/* Image */}
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={cat.image}
                    alt={`${cat.name} - equipment and dashboard`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/40 to-transparent" />

                  {/* Floating glow accent */}
                  <div className={`absolute -bottom-8 left-1/2 h-16 w-3/4 -translate-x-1/2 rounded-full bg-gradient-to-r ${cat.accent} opacity-40 blur-2xl`} />

                  {/* Category number */}
                  <span className="absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-xs font-bold text-white ring-1 ring-white/20 backdrop-blur">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                </div>

                {/* Content */}
                <div className="relative flex flex-1 flex-col p-5">
                  <h3 className="font-display text-base font-bold text-white">{cat.name}</h3>
                  <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-ink-400">{cat.description}</p>

                  {/* Features */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {cat.features.slice(0, 5).map((f) => (
                      <span
                        key={f}
                        className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-2xs font-medium text-ink-300 ring-1 ring-white/10"
                      >
                        <Check className="h-2.5 w-2.5 text-brand-400" />
                        {f}
                      </span>
                    ))}
                    {cat.features.length > 5 && (
                      <span className="inline-flex items-center rounded-full bg-white/5 px-2 py-0.5 text-2xs font-medium text-ink-400 ring-1 ring-white/10">
                        +{cat.features.length - 5} more
                      </span>
                    )}
                  </div>

                  {/* Link */}
                  <Link
                    to="/services"
                    className="mt-5 inline-flex items-center gap-1 text-xs font-semibold text-brand-400 transition-colors hover:text-brand-300"
                  >
                    Explore
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
