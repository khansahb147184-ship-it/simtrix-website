import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { industries } from '@/data/content';
import { Section, SectionContainer } from '@/components/ui/Section';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';

export function IndustriesShowcase() {
  const featured = industries.slice(0, 6);

  return (
    <Section className="bg-ink-50">
      <SectionContainer>
        <div className="flex flex-col items-end justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading
            align="left"
            eyebrow="Industries We Serve"
            title={<>Trusted across diverse sectors</>}
            subtitle="From corporate towers to factories, hospitals to hotels — we tailor smart building solutions to the demands of each industry."
            className="max-w-2xl"
          />
          <Link to="/industries" className="link-underline shrink-0">
            All industries <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((ind, i) => (
            <Reveal key={ind.id} delay={i * 80}>
              <Link
                to="/industries"
                className="group relative block h-full overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-card transition-all duration-500 hover:-translate-y-1 hover:shadow-card-hover"
              >
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={ind.image}
                    alt={ind.name}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-ink-950/20 to-transparent" />
                  <span className="absolute left-4 top-4 flex h-10 w-10 items-center justify-center rounded-xl bg-white/15 text-white ring-1 ring-white/20 backdrop-blur">
                    <ind.icon className="h-5 w-5" />
                  </span>
                  <h3 className="absolute bottom-4 left-4 right-4 font-display text-lg font-semibold text-white">
                    {ind.name}
                  </h3>
                </div>
                <div className="p-6">
                  <p className="text-sm leading-relaxed text-ink-500 line-clamp-2">{ind.description}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {ind.highlights.slice(0, 3).map((h) => (
                      <span key={h} className="rounded-full bg-brand-50 px-3 py-1 text-2xs font-medium text-brand-700">
                        {h}
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </SectionContainer>
    </Section>
  );
}
