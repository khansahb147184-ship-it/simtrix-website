import { Link } from 'react-router-dom';
import { ArrowRight, MapPin, Calendar } from 'lucide-react';
import { projects } from '@/data/content';
import { Section, SectionContainer } from '@/components/ui/Section';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';

export function ProjectsPreview() {
  const featured = projects.slice(0, 3);

  return (
    <Section className="bg-white">
      <SectionContainer>
        <div className="flex flex-col items-end justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading
            align="left"
            eyebrow="Selected Work"
            title={<>Engineering that delivers results</>}
            subtitle="A snapshot of recent projects where our integration and automation expertise made a measurable difference."
            className="max-w-2xl"
          />
          <Link to="/projects" className="link-underline shrink-0">
            View all projects <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {featured.map((p, i) => (
            <Reveal key={p.id} delay={i * 100}>
              <Link
                to="/projects"
                className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-ink-100 bg-white shadow-card transition-all duration-500 hover:-translate-y-2 hover:shadow-card-hover"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={p.image}
                    alt={p.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-ink-950/10 to-transparent" />
                  <span className="absolute left-4 top-4 rounded-full bg-white/15 px-3 py-1 text-2xs font-semibold uppercase tracking-wider text-white ring-1 ring-white/20 backdrop-blur">
                    {p.category}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <h3 className="font-display text-lg font-bold text-ink-900">{p.title}</h3>
                  <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-500">{p.description}</p>

                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {p.scope.slice(0, 3).map((s) => (
                      <span key={s} className="rounded-full bg-ink-50 px-2.5 py-1 text-2xs font-medium text-ink-600">
                        {s}
                      </span>
                    ))}
                  </div>

                  <div className="mt-5 flex items-center justify-between border-t border-ink-100 pt-4 text-xs text-ink-400">
                    <span className="flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5" />
                      {p.location}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Calendar className="h-3.5 w-3.5" />
                      {p.year}
                    </span>
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </SectionContainer>
    </Section>
  );
}
