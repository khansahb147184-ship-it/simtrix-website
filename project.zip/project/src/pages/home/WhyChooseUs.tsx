import { Link } from 'react-router-dom';
import { ArrowRight, Check, Target, Eye, Cpu, ShieldCheck, TrendingUp, Users } from 'lucide-react';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';

const pillars = [
  { icon: Target, title: 'Our Mission', text: 'To engineer smart, efficient and safe built environments through integrated automation and intelligent infrastructure.' },
  { icon: Eye, title: 'Our Vision', text: "To be India's most trusted partner for building automation and smart infrastructure — recognised for engineering excellence and innovation." },
];

const values = [
  { icon: ShieldCheck, title: 'Engineering Integrity', text: 'Every system we deliver is engineered to perform reliably for the long term.' },
  { icon: Cpu, title: 'Innovation First', text: 'We adopt emerging technologies — IIoT, cloud, AI analytics — to deliver future-ready solutions.' },
  { icon: TrendingUp, title: 'Measurable Outcomes', text: 'We design for verifiable energy savings, uptime and operational efficiency.' },
  { icon: Users, title: 'Client Partnership', text: 'We work as an extension of your team — from design to lifetime support.' },
];

export function WhyChooseUs() {
  return (
    <Section className="relative overflow-hidden bg-ink-50">
      <div className="absolute inset-0 grid-bg opacity-40" />
      <div className="absolute -top-32 right-0 h-72 w-72 rounded-full bg-brand-200/40 blur-3xl" />

      <SectionContainer className="relative">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          {/* Left: content */}
          <div>
            <Reveal>
              <span className="eyebrow">
                <span className="h-px w-6 bg-current opacity-60" />
                Why Simtrix
              </span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="section-title mt-4">
                Engineering excellence you can <span className="text-gradient">build on</span>
              </h2>
            </Reveal>
            <Reveal delay={160}>
              <p className="section-subtitle">
                For over a decade, Simtrix Infotech has been the engineering partner of choice for
                organisations that demand more than installation — they demand outcomes.
              </p>
            </Reveal>

            <div className="mt-10 grid gap-5 sm:grid-cols-2">
              {pillars.map((p, i) => (
                <Reveal key={p.title} delay={i * 80}>
                  <div className="rounded-2xl border border-ink-100 bg-white p-6 shadow-card">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                      <p.icon className="h-5 w-5" />
                    </span>
                    <h3 className="mt-4 font-display text-lg font-semibold text-ink-900">{p.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-ink-500">{p.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal delay={240}>
              <Link to="/company" className="link-underline mt-8">
                Learn about our company <ArrowRight className="h-4 w-4" />
              </Link>
            </Reveal>
          </div>

          {/* Right: values grid */}
          <div className="grid gap-4 sm:grid-cols-2">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={i * 80}>
                <div className="group h-full rounded-2xl border border-ink-100 bg-white p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-lg shadow-brand-600/25 transition-transform group-hover:scale-110">
                    <v.icon className="h-6 w-6" />
                  </span>
                  <h3 className="mt-5 font-display text-base font-semibold text-ink-900">{v.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-500">{v.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </SectionContainer>
    </Section>
  );
}
