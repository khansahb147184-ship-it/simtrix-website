import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Play, Building2, Cpu, ShieldCheck, Zap,
  Wifi, Activity, Camera, Network,
} from 'lucide-react';

const floatingCards = [
  { icon: Building2, label: 'BMS', color: 'from-brand-500 to-brand-700', delay: 0 },
  { icon: Cpu, label: 'Automation', color: 'from-accent-500 to-accent-700', delay: 0.15 },
  { icon: ShieldCheck, label: 'Security', color: 'from-success-500 to-success-700', delay: 0.3 },
  { icon: Zap, label: 'Energy', color: 'from-warning-500 to-warning-700', delay: 0.45 },
  { icon: Camera, label: 'CCTV', color: 'from-brand-400 to-brand-600', delay: 0.6 },
  { icon: Network, label: 'IBMS', color: 'from-ink-600 to-ink-800', delay: 0.75 },
];

const stats = [
  { value: 500, suffix: '+', label: 'Projects Delivered' },
  { value: 10, suffix: '+', label: 'Years of Expertise' },
  { value: 30, suffix: '+', label: 'Service Offerings' },
  { value: 98, suffix: '%', label: 'Client Retention' },
];

export function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const rect = heroRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      setMousePos({ x, y });
    };
    const el = heroRef.current;
    el?.addEventListener('mousemove', handleMove);
    return () => el?.removeEventListener('mousemove', handleMove);
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative min-h-[100vh] overflow-hidden bg-ink-950 pt-28 pb-20 lg:pt-32"
    >
      {/* Background layers */}
      <div className="absolute inset-0 grid-bg-dark opacity-50" />
      <div className="absolute inset-0 bg-gradient-to-b from-ink-950 via-ink-950/95 to-ink-900" />

      {/* Glowing orbs with parallax */}
      <motion.div
        style={{ x: mousePos.x * -30, y: mousePos.y * -30 }}
        className="absolute -top-40 -right-20 h-[32rem] w-[32rem] rounded-full bg-brand-600/20 blur-3xl"
      />
      <motion.div
        style={{ x: mousePos.x * 20, y: mousePos.y * 20 }}
        className="absolute top-1/3 -left-40 h-[28rem] w-[28rem] rounded-full bg-accent-500/10 blur-3xl"
      />
      <div className="absolute bottom-0 right-1/4 h-72 w-72 rounded-full bg-brand-500/10 blur-3xl" />

      {/* AI Network animation - connecting lines */}
      <svg className="absolute inset-0 h-full w-full opacity-20" preserveAspectRatio="none">
        <defs>
          <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#338eff" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#338eff" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[
          { x1: '10%', y1: '20%', x2: '40%', y2: '50%' },
          { x1: '40%', y1: '50%', x2: '70%', y2: '30%' },
          { x1: '70%', y1: '30%', x2: '90%', y2: '60%' },
          { x1: '20%', y1: '70%', x2: '50%', y2: '85%' },
          { x1: '50%', y1: '85%', x2: '80%', y2: '75%' },
        ].map((line, i) => (
          <motion.line
            key={i}
            x1={line.x1}
            y1={line.y1}
            x2={line.x2}
            y2={line.y2}
            stroke="url(#lineGrad)"
            strokeWidth="1"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: [0, 0.6, 0] }}
            transition={{ duration: 3, delay: i * 0.4, repeat: Infinity, repeatDelay: 2 }}
          />
        ))}
      </svg>

      {/* Floating network nodes */}
      {[
        { top: '20%', left: '10%', delay: 0 },
        { top: '50%', left: '40%', delay: 0.5 },
        { top: '30%', left: '70%', delay: 1 },
        { top: '70%', left: '20%', delay: 1.5 },
        { top: '85%', left: '50%', delay: 2 },
        { top: '60%', left: '80%', delay: 2.5 },
      ].map((node, i) => (
        <motion.div
          key={i}
          className="absolute z-0"
          style={{ top: node.top, left: node.left }}
          animate={{ scale: [1, 1.5, 1], opacity: [0.3, 0.8, 0.3] }}
          transition={{ duration: 3, delay: node.delay, repeat: Infinity, ease: 'easeInOut' }}
        >
          <div className="h-2 w-2 rounded-full bg-brand-400 shadow-glow" />
        </motion.div>
      ))}

      <div className="container-page relative z-10">
        <div className="grid items-center gap-12 lg:grid-cols-12">
          {/* Left: content */}
          <div className="lg:col-span-6 xl:col-span-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="eyebrow !text-brand-300">
                <span className="h-px w-6 bg-current opacity-60" />
                Engineering & Smart Building Solutions
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="mt-6 font-display text-4xl font-bold leading-[1.05] text-white sm:text-5xl lg:text-6xl xl:text-7xl"
            >
              Building the{' '}
              <span className="text-gradient-light">intelligent infrastructure</span>{' '}
              of tomorrow
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.25 }}
              className="mt-6 max-w-xl text-lg leading-relaxed text-ink-300 sm:text-xl"
            >
              Simtrix Infotech delivers integrated Building Management Systems, Industrial
              Automation, ELV Systems and Smart Infrastructure — engineered for energy
              efficiency, safety and operational excellence across India.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center"
            >
              <Link to="/contact" className="btn-primary group">
                Start a Project
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link to="/services" className="btn-light group">
                <Play className="h-4 w-4 fill-current" />
                Explore Services
              </Link>
            </motion.div>

            {/* Stats with counters */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.55 }}
              className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/5 sm:grid-cols-4"
            >
              {stats.map((s) => (
                <div key={s.label} className="bg-ink-950/40 p-5 backdrop-blur">
                  <div className="font-display text-3xl font-bold text-white">
                    {s.value}{s.suffix && <span className="text-brand-400">{s.suffix}</span>}
                  </div>
                  <div className="mt-1 text-xs font-medium uppercase tracking-wider text-ink-400">
                    {s.label}
                  </div>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right: 3D smart building visual with floating holographic cards */}
          <div className="relative lg:col-span-6 xl:col-span-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative mx-auto aspect-square max-w-[32rem]"
              style={{ perspective: '1200px' }}
            >
              {/* Central building visualization */}
              <motion.div
                style={{
                  transform: `rotateY(${mousePos.x * 15}deg) rotateX(${mousePos.y * -10}deg)`,
                  transformStyle: 'preserve-3d',
                }}
                className="relative h-full w-full"
              >
                {/* Building base glow */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="h-3/4 w-3/4 rounded-3xl bg-gradient-to-b from-brand-600/30 to-transparent blur-2xl" />
                </div>

                {/* 3D Building structure */}
                <div className="absolute inset-0 flex items-end justify-center pb-[15%]">
                  <div className="relative flex h-[70%] w-[55%] flex-col-reverse gap-1.5">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <motion.div
                        key={i}
                        className="relative flex-1 rounded-md border border-brand-400/30 bg-gradient-to-r from-ink-800/80 to-ink-900/80 backdrop-blur"
                        style={{ transform: `translateZ(${i * 8}px)` }}
                        animate={{
                          boxShadow: i % 2 === 0
                            ? ['0 0 0px rgba(51,142,255,0.2)', '0 0 20px rgba(51,142,255,0.4)', '0 0 0px rgba(51,142,255,0.2)']
                            : ['0 0 0px rgba(251,191,36,0.1)', '0 0 15px rgba(251,191,36,0.3)', '0 0 0px rgba(251,191,36,0.1)'],
                        }}
                        transition={{ duration: 3, delay: i * 0.2, repeat: Infinity, ease: 'easeInOut' }}
                      >
                        {/* Window lights */}
                        <div className="flex h-full items-center justify-center gap-1.5 px-2">
                          {Array.from({ length: 4 }).map((_, j) => (
                            <motion.div
                              key={j}
                              className="h-2 w-2 rounded-sm"
                              animate={{
                                opacity: [0.2, 0.9, 0.2],
                                backgroundColor: j % 2 === 0 ? '#338eff' : '#fbbf24',
                              }}
                              transition={{ duration: 2, delay: (i * 0.1 + j * 0.15), repeat: Infinity, ease: 'easeInOut' }}
                            />
                          ))}
                        </div>
                      </motion.div>
                    ))}
                    {/* Building antenna */}
                    <motion.div
                      className="absolute -top-8 left-1/2 h-8 w-0.5 -translate-x-1/2 bg-gradient-to-t from-brand-500 to-transparent"
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <motion.div
                        className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full bg-brand-400"
                        animate={{ scale: [0.8, 1.2, 0.8], opacity: [0.5, 1, 0.5] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                    </motion.div>
                  </div>
                </div>

                {/* Floating holographic service cards */}
                {floatingCards.map((card, i) => {
                  const positions = [
                    { top: '5%', left: '-5%', z: 80 },
                    { top: '15%', right: '-8%', z: 60 },
                    { top: '42%', left: '-10%', z: 40 },
                    { top: '52%', right: '-5%', z: 70 },
                    { top: '78%', left: '0%', z: 50 },
                    { top: '85%', right: '5%', z: 30 },
                  ];
                  const pos = positions[i];
                  return (
                    <motion.div
                      key={card.label}
                      className="absolute"
                      style={{
                        ...pos,
                        transform: `translateZ(${pos.z}px)`,
                      }}
                      animate={{ y: [0, -12, 0] }}
                      transition={{ duration: 4, delay: card.delay, repeat: Infinity, ease: 'easeInOut' }}
                    >
                      <div className={`flex items-center gap-2.5 rounded-2xl bg-gradient-to-br ${card.color} p-3 shadow-xl backdrop-blur-xl ring-1 ring-white/20`}>
                        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/20 text-white">
                          <card.icon className="h-5 w-5" />
                        </span>
                        <span className="pr-1 text-sm font-semibold text-white">{card.label}</span>
                      </div>
                    </motion.div>
                  );
                })}

                {/* AI network scan line */}
                <motion.div
                  className="absolute inset-x-0 h-px bg-gradient-to-r from-transparent via-brand-400 to-transparent"
                  animate={{ top: ['10%', '90%', '10%'] }}
                  transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                  style={{ boxShadow: '0 0 20px rgba(51,142,255,0.6)' }}
                />

                {/* Rotating ring */}
                <motion.div
                  className="absolute left-1/2 top-1/2 h-[85%] w-[85%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-brand-500/20"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                >
                  <div className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full bg-brand-400 shadow-glow" />
                </motion.div>
                <motion.div
                  className="absolute left-1/2 top-1/2 h-[70%] w-[70%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-accent-500/15"
                  animate={{ rotate: -360 }}
                  transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
                >
                  <div className="absolute -top-1.5 right-1/4 h-2.5 w-2.5 rounded-full bg-accent-400" />
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}
