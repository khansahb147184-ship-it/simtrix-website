import { Quote, Star } from 'lucide-react';
import { testimonials } from '@/data/content';
import { Section, SectionContainer } from '@/components/ui/Section';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Reveal } from '@/components/ui/Reveal';
import { ClientLogos } from './ClientLogos';

export function Testimonials() {
  return (
    <Section className="relative overflow-hidden bg-ink-950 py-20 lg:py-28">
      <div className="absolute inset-0 grid-bg-dark opacity-40" />
      <div className="absolute -top-32 left-1/3 h-72 w-72 rounded-full bg-brand-600/15 blur-3xl" />

      <SectionContainer className="relative">
        <SectionHeading
          light
          eyebrow="Client Voices"
          title={<>Trusted by leaders across industries</>}
          subtitle="Our clients measure our work by the outcomes we deliver — energy saved, incidents avoided, operations simplified."
        />

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={i} delay={i * 100}>
              <figure className="flex h-full flex-col rounded-2xl border border-white/10 bg-white/5 p-8 backdrop-blur transition-colors hover:border-white/20">
                <div className="flex items-center gap-1 text-accent-400">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star key={s} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <Quote className="mt-5 h-8 w-8 text-brand-500/40" />
                <blockquote className="mt-3 flex-1 text-base leading-relaxed text-ink-200">
                  "{t.quote}"
                </blockquote>
                <figcaption className="mt-6 border-t border-white/10 pt-5">
                  <div className="font-display text-sm font-semibold text-white">{t.author}</div>
                  <div className="mt-0.5 text-xs text-ink-400">{t.company}</div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        {/* Partners marquee */}
        <ClientLogos />
      </SectionContainer>
    </Section>
  );
}
