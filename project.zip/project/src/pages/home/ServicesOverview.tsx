import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { serviceGroups } from '@/data/services';
import { SectionHeading } from '@/components/ui/SectionHeading';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';

export function ServicesOverview() {
  return (
    <Section className="bg-white">
      <SectionContainer>
        <SectionHeading
          eyebrow="What We Do"
          title={<>End-to-end smart building & automation solutions</>}
          subtitle="From building management to industrial automation, energy intelligence to security — we engineer, integrate and optimise the systems that keep modern facilities running."
        />

        <div className="mt-16 space-y-16">
          {serviceGroups.map((group, gi) => {
            const Icon = group.services[0].icon;
            return (
              <div key={group.id} id={group.id}>
                <Reveal>
                  <div className="flex flex-col gap-4 border-l-2 border-brand-500 pl-5 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                          <Icon className="h-5 w-5" />
                        </span>
                        <h3 className="font-display text-2xl font-bold text-ink-900">{group.title}</h3>
                      </div>
                      <p className="mt-2 max-w-2xl text-sm text-ink-500">{group.description}</p>
                    </div>
                    <Link
                      to="/services"
                      className="group inline-flex shrink-0 items-center gap-1.5 text-sm font-semibold text-brand-600"
                    >
                      View all
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </div>
                </Reveal>

                <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  {group.services.map((service, si) => (
                    <Reveal key={service.id} delay={si * 60}>
                      <Link
                        to={`/services/${service.id}`}
                        className="group flex h-full flex-col rounded-2xl border border-ink-100 bg-white p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-card-hover"
                      >
                        <div className="mb-4 flex items-center justify-between">
                          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ink-50 text-ink-600 transition-all duration-300 group-hover:bg-brand-600 group-hover:text-white">
                            <service.icon className="h-5 w-5" />
                          </span>
                          <span className="text-2xs font-semibold uppercase tracking-wider text-ink-300">
                            {service.short}
                          </span>
                        </div>
                        <h4 className="font-display text-base font-semibold text-ink-900">{service.name}</h4>
                        <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-ink-500">{service.description}</p>
                        <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-600 opacity-0 transition-opacity group-hover:opacity-100">
                          Learn more <ArrowRight className="h-3.5 w-3.5" />
                        </span>
                      </Link>
                    </Reveal>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </SectionContainer>
    </Section>
  );
}
