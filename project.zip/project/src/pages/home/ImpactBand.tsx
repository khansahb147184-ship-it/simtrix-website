import { Zap, ShieldCheck, Activity, TrendingDown } from 'lucide-react';
import { Reveal } from '@/components/ui/Reveal';

const impact = [
  { icon: Zap, value: '30%', label: 'Average energy savings', sub: 'across BMS & HVAC projects' },
  { icon: ShieldCheck, value: '24/7', label: 'Remote monitoring', sub: 'with NOC support & escalation' },
  { icon: Activity, value: '500+', label: 'Systems integrated', sub: 'on open-protocol platforms' },
  { icon: TrendingDown, value: '40%', label: 'Reduced incident response', sub: 'via unified IBMS dashboards' },
];

export function ImpactBand() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-r from-brand-700 to-brand-900 py-16">
      <div className="absolute inset-0 grid-bg-dark opacity-30" />
      <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
      <div className="container-page relative">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {impact.map((item, i) => (
            <Reveal key={item.label} delay={i * 80}>
              <div className="flex items-start gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/10 text-white ring-1 ring-white/20 backdrop-blur">
                  <item.icon className="h-6 w-6" />
                </span>
                <div>
                  <div className="font-display text-3xl font-bold text-white">{item.value}</div>
                  <div className="mt-1 text-sm font-semibold text-brand-100">{item.label}</div>
                  <div className="text-xs text-brand-200/70">{item.sub}</div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
