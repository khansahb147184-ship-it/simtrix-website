import { motion } from 'framer-motion';
import {
  Wind, Flame, Camera, Lock, Car, ArrowUp, Zap, Battery,
  Lightbulb, Gauge, Droplet, Sun, Cloud, Cpu, Monitor, Wifi,
  Building2,
} from 'lucide-react';
import { integrationNodes } from '@/data/ecosystem';
import { Reveal } from '@/components/ui/Reveal';

const iconMap: Record<string, typeof Wind> = {
  Wind, Flame, Camera, Lock, Car, ArrowUp, Zap, Battery,
  Lightbulb, Gauge, Droplet, Sun, Cloud, Cpu, Monitor, Wifi,
};

export function SystemIntegration() {
  const radius = 42;

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-ink-900 to-ink-950 py-24 lg:py-32">
      <div className="absolute inset-0 grid-bg-dark opacity-30" />
      <div className="absolute left-1/2 top-1/2 h-[40rem] w-[40rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-600/10 blur-3xl" />

      <div className="container-page relative">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <span className="eyebrow !text-brand-300">
              <span className="h-px w-6 bg-current opacity-60" />
              System Integration
            </span>
            <h2 className="section-title mt-4 !text-white">
              Every system connected into{' '}
              <span className="text-gradient-light">one BMS dashboard</span>
            </h2>
            <p className="section-subtitle !text-ink-400">
              HVAC, fire, CCTV, access, parking, lift, DG, UPS, lighting, energy, water, solar,
              weather, PLC, SCADA and IoT — all integrated into a single intelligent platform.
            </p>
          </div>
        </Reveal>

        {/* Integration diagram */}
        <Reveal delay={120}>
          <div className="relative mx-auto mt-16 aspect-square max-w-[36rem]">
            {/* SVG connection lines */}
            <svg
              className="absolute inset-0 h-full w-full"
              viewBox="0 0 100 100"
              preserveAspectRatio="xMidYMid meet"
            >
              <defs>
                <radialGradient id="centerGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#338eff" stopOpacity="0.6" />
                  <stop offset="100%" stopColor="#338eff" stopOpacity="0" />
                </radialGradient>
              </defs>

              {/* Center glow circle */}
              <circle cx="50" cy="50" r="20" fill="url(#centerGlow)" />

              {/* Connection lines from each node to center */}
              {integrationNodes.map((node, i) => {
                const rad = (node.angle * Math.PI) / 180;
                const x = 50 + radius * Math.cos(rad);
                const y = 50 + radius * Math.sin(rad);
                return (
                  <motion.line
                    key={node.id}
                    x1={x}
                    y1={y}
                    x2="50"
                    y2="50"
                    stroke="#338eff"
                    strokeWidth="0.3"
                    strokeOpacity="0.4"
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: i * 0.05 }}
                  />
                );
              })}

              {/* Animated data pulses along lines */}
              {integrationNodes.map((node, i) => {
                const rad = (node.angle * Math.PI) / 180;
                const x1 = 50 + radius * Math.cos(rad);
                const y1 = 50 + radius * Math.sin(rad);
                return (
                  <motion.circle
                    key={`pulse-${node.id}`}
                    r="0.8"
                    fill="#59b0ff"
                    initial={{ cx: x1, cy: y1, opacity: 0 }}
                    animate={{
                      cx: [x1, 50],
                      cy: [y1, 50],
                      opacity: [0, 1, 0],
                    }}
                    transition={{
                      duration: 2,
                      delay: i * 0.12,
                      repeat: Infinity,
                      repeatDelay: 1,
                      ease: 'easeInOut',
                    }}
                  />
                );
              })}
            </svg>

            {/* Rotating outer ring */}
            <motion.div
              className="absolute left-1/2 top-1/2 h-[88%] w-[88%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-brand-500/15"
              animate={{ rotate: 360 }}
              transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
            />

            {/* Center BMS Dashboard hub */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <motion.div
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                className="relative flex h-28 w-28 items-center justify-center rounded-3xl bg-gradient-to-br from-brand-500 to-brand-800 shadow-glow-lg ring-2 ring-brand-400/30 sm:h-32 sm:w-32"
              >
                <div className="absolute inset-0 rounded-3xl bg-brand-500/20 blur-xl" />
                <div className="relative flex flex-col items-center">
                  <Building2 className="h-8 w-8 text-white sm:h-10 sm:w-10" />
                  <span className="mt-1 text-2xs font-bold uppercase tracking-wider text-white">BMS</span>
                </div>
              </motion.div>
            </div>

            {/* Node labels positioned around the circle */}
            {integrationNodes.map((node, i) => {
              const rad = (node.angle * Math.PI) / 180;
              const x = 50 + radius * Math.cos(rad);
              const y = 50 + radius * Math.sin(rad);
              const Icon = iconMap[node.icon] ?? Cpu;

              return (
                <motion.div
                  key={node.id}
                  className="absolute z-10"
                  style={{
                    left: `${x}%`,
                    top: `${y}%`,
                    transform: 'translate(-50%, -50%)',
                  }}
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.04 }}
                >
                  <motion.div
                    animate={{ y: [0, -4, 0] }}
                    transition={{
                      duration: 3,
                      delay: i * 0.15,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                    className="group flex flex-col items-center gap-1"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/5 text-brand-300 shadow-lg backdrop-blur-xl transition-colors group-hover:border-brand-400/50 group-hover:bg-brand-500/20 group-hover:text-white sm:h-12 sm:w-12">
                      <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
                    </div>
                    <span className="text-2xs font-semibold text-ink-400 transition-colors group-hover:text-white sm:text-xs">
                      {node.label}
                    </span>
                  </motion.div>
                </motion.div>
              );
            })}
          </div>
        </Reveal>

        {/* Caption */}
        <Reveal delay={200}>
          <p className="mx-auto mt-12 max-w-2xl text-center text-sm leading-relaxed text-ink-400">
            Simtrix Infotech provides complete system integration — every building and industrial
            system connected, monitored and controlled from a single intelligent BMS dashboard with
            real-time data, alarms, analytics and remote access.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
