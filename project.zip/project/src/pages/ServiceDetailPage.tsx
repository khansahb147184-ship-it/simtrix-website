import { useParams, Link, Navigate } from 'react-router-dom';
import { ArrowRight, Check, ArrowLeft, Phone, Star } from 'lucide-react';
import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { ServiceCard } from '@/components/ui/ServiceCard';
import { CTASection } from '@/components/ui/CTASection';
import { getServiceById, getGroupByServiceId, allServices } from '@/data/services';
import { company } from '@/data/company';

export function ServiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const service = id ? getServiceById(id) : undefined;

  if (!service) return <Navigate to="/services" replace />;

  const group = getGroupByServiceId(service.id);
  const Icon = service.icon;
  const related = allServices.filter((s) => s.id !== service.id).slice(0, 3);

  return (
    <>
      <PageHero
        eyebrow={group?.title ?? 'Services'}
        title={service.name}
        subtitle={service.description}
        breadcrumbs={[{ label: 'Services', href: '/services' }, { label: service.name }]}
      >
        <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-lg shadow-brand-600/30">
            <Icon className="h-8 w-8" />
          </span>
          <div className="flex flex-wrap gap-3">
            <Link to="/contact" className="btn-primary group">
              Request a Quote <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <a href={company.phoneHref} className="btn-light">
              <Phone className="h-4 w-4" /> {company.phone}
            </a>
          </div>
        </div>
      </PageHero>

      <Section className="bg-white">
        <SectionContainer>
          <div className="grid gap-12 lg:grid-cols-3">
            {/* Main content */}
            <div className="lg:col-span-2">
              <Reveal>
                <h2 className="font-display text-2xl font-bold text-ink-900">Overview</h2>
                <p className="mt-4 text-base leading-relaxed text-ink-600">{service.description}</p>
              </Reveal>

              <Reveal delay={80}>
                <h3 className="mt-12 font-display text-xl font-semibold text-ink-900">Key Features</h3>
                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  {service.features.map((f, i) => (
                    <div key={f} className="flex items-start gap-3 rounded-xl border border-ink-100 bg-ink-50/40 p-4">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-success-100 text-success-600">
                        <Check className="h-4 w-4" />
                      </span>
                      <span className="text-sm font-medium text-ink-700">{f}</span>
                    </div>
                  ))}
                </div>
              </Reveal>

              <Reveal delay={160}>
                <h3 className="mt-12 font-display text-xl font-semibold text-ink-900">Benefits</h3>
                <div className="mt-6 space-y-3">
                  {service.benefits.map((b) => (
                    <div key={b} className="flex items-center gap-3">
                      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-100 text-brand-700">
                        <Star className="h-4 w-4 fill-current" />
                      </span>
                      <span className="text-sm font-medium text-ink-700">{b}</span>
                    </div>
                  ))}
                </div>
              </Reveal>
            </div>

            {/* Sidebar */}
            <aside className="lg:col-span-1">
              <Reveal delay={120}>
                <div className="sticky top-28 rounded-2xl border border-ink-100 bg-ink-50/50 p-6">
                  <h3 className="font-display text-base font-semibold text-ink-900">Quick Facts</h3>
                  <dl className="mt-4 space-y-3 text-sm">
                    <div className="flex justify-between border-b border-ink-100 pb-3">
                      <dt className="text-ink-500">Category</dt>
                      <dd className="font-semibold text-ink-800">{group?.title}</dd>
                    </div>
                    <div className="flex justify-between border-b border-ink-100 pb-3">
                      <dt className="text-ink-500">Short Code</dt>
                      <dd className="font-semibold text-ink-800">{service.short}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-ink-500">Delivery</dt>
                      <dd className="font-semibold text-ink-800">Turnkey</dd>
                    </div>
                  </dl>

                  <Link to="/contact" className="btn-primary mt-6 w-full">
                    Get a Quote <ArrowRight className="h-4 w-4" />
                  </Link>
                  <Link to="/services" className="mt-3 flex items-center justify-center gap-2 text-sm font-semibold text-ink-600 hover:text-brand-700">
                    <ArrowLeft className="h-4 w-4" /> All services
                  </Link>
                </div>
              </Reveal>
            </aside>
          </div>
        </SectionContainer>
      </Section>

      {/* Related services */}
      <Section className="bg-ink-50/50 pt-0">
        <SectionContainer>
          <Reveal>
            <h2 className="section-title !text-2xl">Related services</h2>
          </Reveal>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((s, i) => (
              <ServiceCard key={s.id} service={s} variant="compact" index={i} />
            ))}
          </div>
        </SectionContainer>
      </Section>

      <CTASection />
    </>
  );
}
