import { PageHero } from '@/components/ui/PageHero';
import { Section, SectionContainer } from '@/components/ui/Section';
import { Reveal } from '@/components/ui/Reveal';
import { ServiceCard } from '@/components/ui/ServiceCard';
import { CTASection } from '@/components/ui/CTASection';
import { serviceGroups } from '@/data/services';

export function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Our Services"
        title={<>Comprehensive smart building & automation services</>}
        subtitle="Thirty-plus specialised services across building automation, industrial control, energy management, life safety, security, IT infrastructure and smart systems — engineered and integrated by one team."
        breadcrumbs={[{ label: 'Services' }]}
      />

      {serviceGroups.map((group) => {
        const GroupIcon = group.services[0].icon;
        return (
        <Section key={group.id} className={group.id === 'building-automation' ? 'bg-white pt-16' : 'bg-ink-50/50'}>
          <SectionContainer>
            <Reveal>
              <div className="flex items-center gap-4">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-lg shadow-brand-600/25">
                  <GroupIcon className="h-7 w-7" />
                </span>
                <div>
                  <span className="eyebrow">{group.tagline}</span>
                  <h2 className="section-title mt-1 !text-2xl sm:!text-3xl">{group.title}</h2>
                </div>
              </div>
            </Reveal>
            <Reveal delay={80}>
              <p className="mt-5 max-w-3xl text-base leading-relaxed text-ink-500">{group.description}</p>
            </Reveal>

            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {group.services.map((service, i) => (
                <ServiceCard key={service.id} service={service} index={i} />
              ))}
            </div>
          </SectionContainer>
        </Section>
        );
      })}

      <CTASection
        title="Need a service we haven't listed?"
        subtitle="We deliver custom integration and automation solutions too. Tell us what you're trying to achieve."
        primaryLabel="Talk to an Engineer"
      />
    </>
  );
}
