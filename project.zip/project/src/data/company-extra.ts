export type TimelineEvent = {
  year: string;
  title: string;
  description: string;
};

export const timeline: TimelineEvent[] = [
  {
    year: '2015',
    title: 'Company Founded',
    description: 'Simtrix Infotech India Pvt Ltd established in New Delhi with a vision to deliver integrated smart building solutions.',
  },
  {
    year: '2017',
    title: 'First Major IBMS Project',
    description: 'Delivered our first large-scale IBMS integration for a corporate tower, establishing our reputation for engineering excellence.',
  },
  {
    year: '2019',
    title: 'Industrial Automation Division',
    description: 'Expanded into PLC and SCADA automation for manufacturing, adding industrial control capabilities.',
  },
  {
    year: '2021',
    title: 'IoT & Cloud Monitoring Launch',
    description: 'Launched our Industrial IoT and cloud-based remote monitoring platform for multi-site oversight.',
  },
  {
    year: '2023',
    title: '500+ Projects Milestone',
    description: 'Crossed 500 delivered projects across 12 industries, with 98% client retention.',
  },
  {
    year: '2024',
    title: 'AI Video Analytics',
    description: 'Deployed AI-powered video analytics and ANPR solutions for airports, malls and corporate campuses.',
  },
];

export type TeamMember = {
  name: string;
  role: string;
  bio: string;
  image: string;
};

export const team: TeamMember[] = [
  {
    name: 'Engineering Leadership',
    role: 'Founder & Managing Director',
    bio: 'Over 15 years of experience in building automation and industrial control systems, leading Simtrix since its founding in 2015.',
    image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=600&h=600&dpr=2',
  },
  {
    name: 'Automation Head',
    role: 'Head of Industrial Automation',
    bio: 'Specialist in PLC, SCADA and IIoT systems with extensive experience across manufacturing and process industries.',
    image: 'https://images.pexels.com/photos/3777943/pexels-photo-3777943.jpeg?auto=compress&cs=tinysrgb&w=600&h=600&dpr=2',
  },
  {
    name: 'Building Systems Lead',
    role: 'Head of Building Automation',
    bio: 'Expert in BMS, IBMS and HVAC automation with a track record of delivering energy-efficient smart building projects.',
    image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=600&h=600&dpr=2',
  },
  {
    name: 'ELV & Security Manager',
    role: 'Head of ELV & Security Systems',
    bio: 'Leads our ELV integration practice covering CCTV, access control, fire alarm and structured cabling.',
    image: 'https://images.pexels.com/photos/3785079/pexels-photo-3785079.jpeg?auto=compress&cs=tinysrgb&w=600&h=600&dpr=2',
  },
];

export type Award = {
  title: string;
  year: string;
  description: string;
};

export const awards: Award[] = [
  { title: 'Excellence in Building Automation', year: '2023', description: 'Recognised for outstanding IBMS integration across corporate and healthcare projects.' },
  { title: 'Top System Integrator Award', year: '2022', description: 'Awarded for excellence in ELV and security system integration.' },
  { title: 'Energy Efficiency Champion', year: '2024', description: 'Honoured for delivering measurable energy savings through smart building automation.' },
];
