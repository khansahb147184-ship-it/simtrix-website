export type EcosystemCategory = {
  id: string;
  name: string;
  description: string;
  image: string;
  features: string[];
  accent: string;
};

export const ecosystemCategories: EcosystemCategory[] = [
  {
    id: 'bms',
    name: 'Building Management System',
    description:
      'Centralised monitoring and control of HVAC, lighting, power and energy from a single intelligent dashboard with remote access.',
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Building Monitoring', 'HVAC Control', 'Lighting Control', 'Energy Monitoring', 'Remote Monitoring', 'Integration'],
    accent: 'from-brand-500 to-brand-700',
  },
  {
    id: 'hvac-automation',
    name: 'HVAC Automation',
    description:
      'Precision climate control with AHU, FCU, chiller and cooling tower integration — optimised for comfort and energy efficiency.',
    image: 'https://images.pexels.com/photos/3807277/pexels-photo-3807277.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['AHU', 'FCU', 'Chiller', 'Cooling Tower', 'VFD', 'Temperature Sensors', 'Humidity Sensors', 'Actuators'],
    accent: 'from-cyan-500 to-brand-700',
  },
  {
    id: 'plc-automation',
    name: 'PLC Automation',
    description:
      'Industrial-grade PLC control systems from Siemens and Schneider with HMI interfaces, IO modules and custom panel building.',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Siemens PLC', 'Schneider PLC', 'HMI', 'Industrial IO', 'Industrial Panel'],
    accent: 'from-accent-500 to-accent-700',
  },
  {
    id: 'scada',
    name: 'SCADA',
    description:
      'Real-time supervisory control and data acquisition with large control room visualisation, trend graphs, alarm management and automated reports.',
    image: 'https://images.pexels.com/photos/7988079/pexels-photo-7988079.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Large Control Room', 'SCADA Dashboard', 'Trend Graph', 'Alarm Screen', 'Reports'],
    accent: 'from-brand-600 to-ink-800',
  },
  {
    id: 'fire-alarm',
    name: 'Fire Alarm System',
    description:
      'Addressable fire detection with smoke, heat and multi-sensor detectors, manual call points, hooters and extinguisher integration.',
    image: 'https://images.pexels.com/photos/8358208/pexels-photo-8358208.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Fire Alarm Panel', 'Smoke Detector', 'Heat Detector', 'MCP', 'Hooter', 'Fire Extinguisher'],
    accent: 'from-error-500 to-error-700',
  },
  {
    id: 'cctv',
    name: 'CCTV Surveillance',
    description:
      'Enterprise IP video surveillance with PTZ, bullet and dome cameras, NVR recording, video walls and AI-powered analytics.',
    image: 'https://images.pexels.com/photos/430208/pexels-photo-430208.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['IP Camera', 'PTZ Camera', 'Bullet Camera', 'NVR', 'Video Wall', 'AI Analytics'],
    accent: 'from-brand-400 to-brand-800',
  },
  {
    id: 'access-control',
    name: 'Access Control',
    description:
      'Multi-credential access control with biometric, RFID and face recognition, turnstiles, door controllers and electromagnetic locks.',
    image: 'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Biometric Device', 'RFID Reader', 'Face Recognition', 'Turnstile', 'Door Controller', 'Electromagnetic Lock'],
    accent: 'from-success-500 to-success-700',
  },
  {
    id: 'parking-management',
    name: 'Parking Management',
    description:
      'Smart parking with boom barriers, ANPR cameras, bay sensors, ticket machines, LED guidance displays and parking management software.',
    image: 'https://images.pexels.com/photos/905491/pexels-photo-905491.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Boom Barrier', 'ANPR Camera', 'Parking Sensor', 'Ticket Machine', 'LED Display', 'Parking Software'],
    accent: 'from-warning-500 to-warning-700',
  },
  {
    id: 'elv-systems',
    name: 'ELV Systems',
    description:
      'Complete extra-low-voltage integration with structured cabling, networking racks, fibre, PA systems, video door phones and intercoms.',
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Structured Cabling', 'Networking Rack', 'Fibre', 'PA System', 'Video Door Phone', 'Intercom'],
    accent: 'from-ink-600 to-ink-900',
  },
  {
    id: 'networking',
    name: 'Networking',
    description:
      'Enterprise network infrastructure with core and access switches, routers, firewalls, WiFi access points and server racks.',
    image: 'https://images.pexels.com/photos/4348404/pexels-photo-4348404.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Core Switch', 'Access Switch', 'Router', 'Firewall', 'WiFi Access Point', 'Server Rack'],
    accent: 'from-brand-500 to-cyan-700',
  },
  {
    id: 'iot-cloud',
    name: 'IoT & Cloud',
    description:
      'Cloud-connected IoT platform with edge gateways, remote monitoring, predictive analytics, energy dashboards and mobile app access.',
    image: 'https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['Cloud Dashboard', 'IoT Gateway', 'Remote Monitoring', 'Predictive Analytics', 'Energy Dashboard', 'Mobile App'],
    accent: 'from-brand-400 to-success-600',
  },
  {
    id: 'software-integration',
    name: 'Software Integration',
    description:
      'Unified software layer connecting BMS, SCADA, energy management and cloud analytics with alarm management, trend logs, reports and mobile dashboards.',
    image: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    features: ['BMS Software', 'SCADA Software', 'Energy Management Software', 'Remote Desktop', 'Cloud Analytics', 'Alarm Management', 'Trend Logs', 'Reports', 'Mobile Dashboard'],
    accent: 'from-brand-600 to-accent-600',
  },
];

export type IntegrationNode = {
  id: string;
  label: string;
  angle: number;
  icon: string;
};

export const integrationNodes: IntegrationNode[] = [
  { id: 'hvac', label: 'HVAC', angle: 0, icon: 'Wind' },
  { id: 'fire', label: 'Fire', angle: 22, icon: 'Flame' },
  { id: 'cctv', label: 'CCTV', angle: 44, icon: 'Camera' },
  { id: 'access', label: 'Access', angle: 66, icon: 'Lock' },
  { id: 'parking', label: 'Parking', angle: 88, icon: 'Car' },
  { id: 'lift', label: 'Lift', angle: 110, icon: 'ArrowUp' },
  { id: 'dg', label: 'DG', angle: 132, icon: 'Zap' },
  { id: 'ups', label: 'UPS', angle: 154, icon: 'Battery' },
  { id: 'lighting', label: 'Lighting', angle: 176, icon: 'Lightbulb' },
  { id: 'energy', label: 'Energy Meter', angle: 198, icon: 'Gauge' },
  { id: 'water', label: 'Water Meter', angle: 220, icon: 'Droplet' },
  { id: 'solar', label: 'Solar', angle: 242, icon: 'Sun' },
  { id: 'weather', label: 'Weather', angle: 264, icon: 'Cloud' },
  { id: 'plc', label: 'PLC', angle: 286, icon: 'Cpu' },
  { id: 'scada', label: 'SCADA', angle: 308, icon: 'Monitor' },
  { id: 'iot', label: 'IoT', angle: 330, icon: 'Wifi' },
];

export const whyChooseStats = [
  { value: '25', suffix: '+', label: 'Years Experience' },
  { value: '500', suffix: '+', label: 'Projects' },
  { value: '350', suffix: '+', label: 'Clients' },
  { value: '100', suffix: '%', label: 'AMC Support' },
  { value: '24', suffix: 'x7', label: 'Remote Support' },
  { value: 'Pan', suffix: ' India', label: 'Service Network' },
  { value: 'OEM', suffix: '', label: 'Certified Engineers' },
  { value: 'Enterprise', suffix: '', label: 'Integration Experts' },
];
