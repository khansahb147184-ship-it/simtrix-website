import type { LucideIcon } from 'lucide-react';
import {
  Building, Factory, Hotel, HeartPulse, ShoppingBag, Plane,
  School, Banknote, Server, Home, Warehouse, Car,
} from 'lucide-react';

export type Industry = {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  highlights: string[];
  image: string;
};

export const industries: Industry[] = [
  {
    id: 'commercial',
    name: 'Commercial Buildings',
    description:
      'Office towers, corporate campuses and IT parks demand integrated BMS, security and energy management to deliver productive, efficient and secure environments.',
    icon: Building,
    highlights: ['BMS & IBMS', 'Access Control & Visitor Management', 'Energy Analytics', 'CCTV & Video Analytics'],
    image: 'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'industrial',
    name: 'Industrial & Manufacturing',
    description:
      'Factories and process plants rely on PLC, SCADA and Industrial IoT for reliable automation, real-time visibility and predictive maintenance.',
    icon: Factory,
    highlights: ['PLC & SCADA', 'Industrial IoT', 'Energy Management', 'Remote Monitoring'],
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'hospitality',
    name: 'Hotels & Hospitality',
    description:
      'Hotels and resorts use building automation, guest-room control and integrated security to elevate guest experience while optimising energy use.',
    icon: Hotel,
    highlights: ['Guest Room Automation', 'BMS & HVAC', 'Access & Surveillance', 'Energy Optimisation'],
    image: 'https://images.pexels.com/photos/261101/pexels-photo-261101.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'healthcare',
    name: 'Healthcare & Hospitals',
    description:
      'Hospitals require precise environmental control, life-safety systems and secure access to protect patients, staff and critical operations.',
    icon: HeartPulse,
    highlights: ['HVAC & Cleanroom Control', 'Fire & Nurse Call', 'Access Control', 'Medical Gas Monitoring'],
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'retail',
    name: 'Retail & Malls',
    description:
      'Shopping centres and retail chains leverage BMS, parking guidance, CCTV and energy management to enhance shopper experience and reduce costs.',
    icon: ShoppingBag,
    highlights: ['Parking Guidance & ANPR', 'CCTV & Video Analytics', 'BMS & Energy', 'Public Address'],
    image: 'https://images.pexels.com/photos/5650026/pexels-photo-5650026.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'transportation',
    name: 'Airports & Transit',
    description:
      'Airports, metro and transit hubs depend on integrated ELV, surveillance and building automation for safe, efficient passenger movement.',
    icon: Plane,
    highlights: ['CCTV & Video Analytics', 'Access & ANPR', 'BMS & HVAC', 'Public Address'],
    image: 'https://images.pexels.com/photos/9558760/pexels-photo-9558760.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'education',
    name: 'Education & Campuses',
    description:
      'Universities and schools use smart building systems to create safe, energy-efficient and connected learning environments.',
    icon: School,
    highlights: ['BMS & Energy', 'Access & Surveillance', 'Networking & Cabling', 'Fire & PA'],
    image: 'https://images.pexels.com/photos/207692/pexels-photo-207692.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'data-centers',
    name: 'Data Centers & IT',
    description:
      'Mission-critical facilities need precision cooling, power management, environmental monitoring and robust security for guaranteed uptime.',
    icon: Server,
    highlights: ['DCIM & Environmental Monitoring', 'Precision Cooling', 'Fire Suppression', 'Access & CCTV'],
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'residential',
    name: 'Residential & Villas',
    description:
      'Luxury homes and residential complexes benefit from home automation, smart security and integrated ELV for comfort and peace of mind.',
    icon: Home,
    highlights: ['Home Automation', 'Smart Security', 'Access & Boom Barrier', 'Networking'],
    image: 'https://images.pexels.com/photos/32870/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'pharma',
    name: 'Pharmaceutical',
    description:
      'Pharma and cleanroom facilities require stringent environmental control, GMP-compliant monitoring and validated automation systems.',
    icon: Warehouse,
    highlights: ['HVAC & Cleanroom Control', 'GMP Monitoring', 'SCADA & Historian', 'Access Control'],
    image: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'logistics',
    name: 'Logistics & Warehousing',
    description:
      'Distribution centres and warehouses use automation, surveillance and energy management to secure assets and streamline operations.',
    icon: Car,
    highlights: ['CCTV & ANPR', 'BMS & Energy', 'Networking & Cabling', 'Access Control'],
    image: 'https://images.pexels.com/photos/905491/pexels-photo-905491.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
  {
    id: 'banking',
    name: 'Banking & Finance',
    description:
      'Banks and financial institutions rely on robust physical security, surveillance and access control to protect people and assets.',
    icon: Banknote,
    highlights: ['CCTV & Video Analytics', 'Access & Vault Control', 'Fire & Safety', 'Networking'],
    image: 'https://images.pexels.com/photos/210607/pexels-photo-210607.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
  },
];

export type Project = {
  id: string;
  title: string;
  client: string;
  industry: string;
  location: string;
  year: string;
  scope: string[];
  technology: string[];
  description: string;
  image: string;
  category: string;
  status: 'Completed' | 'Ongoing' | 'Commissioned';
};

export const projects: Project[] = [
  {
    id: 'jaquar-bhachau',
    title: 'Jaquar & Co Manufacturing Plant',
    client: 'Jaquar & Co',
    industry: 'Industrial & Manufacturing',
    location: 'Bhachau, Gujarat',
    year: '2023',
    scope: ['PLC Automation', 'SCADA', 'Energy Management', 'HVAC Automation'],
    technology: ['Siemens S7-1500 PLC', 'WinCC SCADA', 'Modbus TCP', 'BACnet'],
    description:
      'Turnkey PLC and SCADA automation for a large-scale faucet manufacturing facility, including motor control centres, energy monitoring and real-time OEE dashboards across multiple production lines.',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Industrial Automation',
    status: 'Completed',
  },
  {
    id: 'garden-galleria-mall',
    title: 'Garden Galleria Mall',
    client: 'Garden Galleria',
    industry: 'Retail & Malls',
    location: 'Lucknow, Uttar Pradesh',
    year: '2023',
    scope: ['BMS', 'HVAC Automation', 'CCTV', 'Access Control', 'Parking Guidance'],
    technology: ['Honeywell BMS', 'Hikvision CCTV', 'BACnet', 'Modbus'],
    description:
      'Integrated BMS, HVAC automation, IP surveillance and parking guidance across a premium shopping mall, delivering centralised control and 25% energy savings through intelligent scheduling.',
    image: 'https://images.pexels.com/photos/5650026/pexels-photo-5650026.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Smart Buildings',
    status: 'Completed',
  },
  {
    id: 'moodys-noida',
    title: "Moody's Office",
    client: "Moody's",
    industry: 'Commercial Buildings',
    location: 'Noida, Uttar Pradesh',
    year: '2024',
    scope: ['IBMS', 'Access Control', 'CCTV', 'Fire Alarm', 'Networking'],
    technology: ['Schneider IBMS', 'Honeywell Fire', 'Axis CCTV', 'Cisco Networking'],
    description:
      'Complete IBMS integration for a corporate office, unifying HVAC, lighting, fire, security and access on a single platform with cloud-based remote monitoring.',
    image: 'https://images.pexels.com/photos/302769/pexels-photo-302769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Smart Buildings',
    status: 'Completed',
  },
  {
    id: 'bc-management-noida',
    title: 'BC Management Office',
    client: 'BC Management',
    industry: 'Commercial Buildings',
    location: 'Noida, Uttar Pradesh',
    year: '2023',
    scope: ['BMS', 'HVAC Automation', 'Energy Management', 'Access Control'],
    technology: ['Delta BMS', 'BACnet', 'Schneider Power Monitoring'],
    description:
      'Building management system and energy monitoring for a corporate office, with occupancy-based HVAC control and real-time energy dashboards.',
    image: 'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Smart Buildings',
    status: 'Completed',
  },
  {
    id: 'd-nova-infosys',
    title: 'D Nova Infosys',
    client: 'D Nova Infosys',
    industry: 'Commercial Buildings',
    location: 'Noida, Uttar Pradesh',
    year: '2024',
    scope: ['ELV Systems', 'Networking', 'CCTV', 'Access Control', 'Structured Cabling'],
    technology: ['Legrand Cabling', 'Aruba Networking', 'Hikvision CCTV', 'Honeywell Access'],
    description:
      'Complete ELV and IT infrastructure for a corporate IT office, including structured cabling, enterprise networking, surveillance and access control.',
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'ELV & IT',
    status: 'Completed',
  },
  {
    id: 'aima-delhi',
    title: 'AIMA Office',
    client: 'AIMA (All India Management Association)',
    industry: 'Commercial Buildings',
    location: 'New Delhi',
    year: '2023',
    scope: ['BMS', 'Fire Alarm', 'Public Address', 'Access Control', 'CCTV'],
    technology: ['Honeywell BMS', 'Honeywell Fire', 'Bosch PA', 'Hikvision CCTV'],
    description:
      'Integrated building management, fire alarm, public address and surveillance for a management institution campus in New Delhi.',
    image: 'https://images.pexels.com/photos/207692/pexels-photo-207692.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Smart Buildings',
    status: 'Completed',
  },
  {
    id: 'apollo-medics',
    title: 'Apollo Medics Hospital',
    client: 'Apollo Medics',
    industry: 'Healthcare & Hospitals',
    location: 'Lucknow, Uttar Pradesh',
    year: '2024',
    scope: ['HVAC Automation', 'Fire Alarm', 'Access Control', 'Nurse Call Integration', 'Medical Gas Monitoring'],
    technology: ['Siemens HVAC', 'Honeywell Fire', 'Schneider Access', 'BACnet'],
    description:
      'Hospital automation including HVAC plant control, addressable fire alarm, access control and integration with nurse-call and medical-gas monitoring systems.',
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Life Safety',
    status: 'Completed',
  },
  {
    id: 'grant-thornton-kolkata',
    title: 'Grant Thornton Office',
    client: 'Grant Thornton',
    industry: 'Commercial Buildings',
    location: 'Kolkata, West Bengal',
    year: '2023',
    scope: ['IBMS', 'Access Control', 'CCTV', 'Networking', 'Fire Alarm'],
    technology: ['Johnson Controls IBMS', 'Axis CCTV', 'Cisco Networking', 'Honeywell Fire'],
    description:
      'IBMS integration for a professional services firm, delivering unified control of HVAC, lighting, security and fire systems with remote monitoring.',
    image: 'https://images.pexels.com/photos/302769/pexels-photo-302769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Smart Buildings',
    status: 'Completed',
  },
  {
    id: 'uniworld-ta-gurgaon',
    title: 'Uniworld T-A Towers',
    client: 'Uniworld T-A',
    industry: 'Commercial Buildings',
    location: 'Gurgaon, Haryana',
    year: '2024',
    scope: ['BMS', 'HVAC Automation', 'Access Control', 'CCTV', 'Boom Barrier'],
    technology: ['Honeywell BMS', 'BACnet', 'Hikvision CCTV', 'FAAC Boom Barrier'],
    description:
      'Smart building automation for a commercial tower complex, including BMS, HVAC, access control, surveillance and automated boom barriers for parking.',
    image: 'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Smart Buildings',
    status: 'Ongoing',
  },
  {
    id: 'united-limited-gurgaon',
    title: 'United Limited Corporate Office',
    client: 'United Limited',
    industry: 'Commercial Buildings',
    location: 'Gurgaon, Haryana',
    year: '2023',
    scope: ['ELV Systems', 'CCTV', 'Access Control', 'Networking', 'Structured Cabling'],
    technology: ['Legrand Cabling', 'D-Link Networking', 'Hikvision CCTV', 'Honeywell Access'],
    description:
      'Complete ELV systems integration for a corporate office, including structured cabling, networking, surveillance and access control.',
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'ELV & IT',
    status: 'Completed',
  },
  {
    id: 'markem-imaje-alwar',
    title: 'Markem Imaje Manufacturing',
    client: 'Markem Imaje',
    industry: 'Industrial & Manufacturing',
    location: 'Alwar, Rajasthan',
    year: '2023',
    scope: ['PLC Automation', 'SCADA', 'Industrial IoT', 'Energy Management'],
    technology: ['Mitsubishi PLC', 'Wonderware SCADA', 'OPC UA', 'MQTT'],
    description:
      'Industrial automation for a coding and marking equipment manufacturer, with PLC control, SCADA visualisation and IIoT connectivity for predictive maintenance.',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Industrial Automation',
    status: 'Completed',
  },
  {
    id: 'darbhanga-airport',
    title: 'Darbhanga Airport',
    client: 'Darbhanga Airport Authority',
    industry: 'Airports & Transit',
    location: 'Darbhanga, Bihar',
    year: '2024',
    scope: ['CCTV', 'Video Analytics', 'Access Control', 'ANPR Parking', 'Fire Alarm', 'Public Address'],
    technology: ['Hikvision CCTV', 'Hikvision ANPR', 'Honeywell Fire', 'Bosch PA', 'BACnet'],
    description:
      'Airport security and automation including IP surveillance with video analytics, ANPR-based parking, access control, fire alarm and public address systems.',
    image: 'https://images.pexels.com/photos/9558760/pexels-photo-9558760.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Parking & Surveillance',
    status: 'Completed',
  },
  {
    id: 'esic-hospital',
    title: 'ESIC Hospital',
    client: 'ESIC',
    industry: 'Healthcare & Hospitals',
    location: 'New Delhi',
    year: '2022',
    scope: ['HVAC Automation', 'Fire Alarm', 'Access Control', 'BMS', 'Nurse Call Integration'],
    technology: ['Siemens BMS', 'Honeywell Fire', 'BACnet', 'Schneider Access'],
    description:
      'Hospital BMS and life safety integration for an ESIC facility, including HVAC automation, fire alarm, access control and nurse-call system integration.',
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    category: 'Life Safety',
    status: 'Commissioned',
  },
];

export const certifications = [
  'ISO 9001:2015',
  'ISO 27001',
  'BACnet Certified',
  'MSME Registered',
  'CE Marked Products',
];

export const clients = [
  'Siemens', 'Schneider', 'Honeywell', 'ABB',
  'Johnson Controls', 'Greystone', 'Hikvision', 'D-Link',
  'Aruba', 'TP-Link', 'Legrand', 'Jaquar',
  'AIMA', 'Markem Imaje', 'Apollo Medics', 'Grant Thornton',
  'Darbhanga Airport',
];

export const testimonials = [
  {
    quote:
      'Simtrix delivered our IBMS integration on time and on budget. The unified dashboard transformed how our facilities team operates — we now resolve incidents in minutes instead of hours.',
    author: 'Head of Facilities',
    company: 'Corporate Tower, Gurugram',
  },
  {
    quote:
      'Their SCADA and IIoT expertise gave us real-time visibility across our production lines. OEE improved measurably within the first quarter of deployment.',
    author: 'Plant Manager',
    company: 'Precision Manufacturing, Manesar',
  },
  {
    quote:
      'From fire alarm to access control, Simtrix integrated every life-safety system in our hospital with zero disruption to patient care. Exceptional engineering.',
    author: 'Director of Operations',
    company: 'Multi-Speciality Hospital, Noida',
  },
];
