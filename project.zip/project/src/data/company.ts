import type { LucideIcon } from 'lucide-react';
import {
  Building2, Network, Cpu, Flame, Car, Camera, Wifi, Layers,
  Wrench, Zap, ShieldCheck, Phone, Mail, MapPin, Clock,
  Boxes, Images, Download,
} from 'lucide-react';

export const company = {
  name: 'Simtrix Infotech India Pvt Ltd',
  shortName: 'Simtrix Infotech',
  tagline: 'Engineering | Building Automation | Smart Infrastructure',
  description:
    'Simtrix Infotech India Pvt Ltd is a premier engineering and smart building solutions company delivering Building Management Systems, Industrial Automation, ELV Systems and Smart Infrastructure across India.',
  foundedYear: 2015,
  phone: '+91 9355026226',
  phoneHref: 'tel:+919355026226',
  email: 'sales@simtrix.in',
  emailHref: 'mailto:sales@simtrix.in',
  address: {
    line1: 'First Floor, Plot-6',
    line2: 'Street Number 3',
    line3: 'East Guru Angad Nagar',
    line4: 'Swasthya Vihar',
    city: 'New Delhi',
    state: 'Delhi',
    pincode: '110092',
    country: 'India',
  },
  hours: 'Mon - Sat: 9:30 AM - 6:30 PM',
};

export const stats: { value: string; label: string; suffix?: string }[] = [
  { value: '500', label: 'Projects Delivered', suffix: '+' },
  { value: '10', label: 'Years of Expertise', suffix: '+' },
  { value: '30', label: 'Service Offerings', suffix: '+' },
  { value: '98', label: 'Client Retention', suffix: '%' },
];

export const navLinks: {
  label: string;
  href: string;
  children?: { label: string; href: string; description: string; icon: LucideIcon }[];
}[] = [
  { label: 'Home', href: '/' },
  {
    label: 'Services',
    href: '/services',
    children: [
      { label: 'Building Management System', href: '/services/bms', description: 'Centralised control of HVAC, lighting & power', icon: Building2 },
      { label: 'IBMS', href: '/services/ibms', description: 'Single pane of glass for all building systems', icon: Network },
      { label: 'Building Automation', href: '/services/building-automation', description: 'DDC-based programmable building control', icon: Cpu },
      { label: 'HVAC Automation', href: '/services/hvac-automation', description: 'Precision climate & ventilation control', icon: Zap },
      { label: 'PLC & SCADA', href: '/services/plc-automation', description: 'Industrial process control & visualisation', icon: Cpu },
      { label: 'Fire Alarm System', href: '/services/fire-alarm', description: 'Addressable detection & evacuation', icon: Flame },
      { label: 'CCTV & Video Analytics', href: '/services/cctv-surveillance', description: 'AI-powered surveillance & insight', icon: Camera },
      { label: 'Access Control', href: '/services/access-control', description: 'Credential-based entry & audit trails', icon: ShieldCheck },
      { label: 'Networking & Cabling', href: '/services/networking', description: 'Structured cabling & enterprise networks', icon: Wifi },
      { label: 'ELV Systems', href: '/services/elv-systems', description: 'Unified extra-low-voltage integration', icon: Layers },
      { label: 'Industrial IoT', href: '/services/industrial-iot', description: 'Cloud-connected asset intelligence', icon: Cpu },
      { label: 'AMC Services', href: '/services/amc-services', description: 'Annual maintenance & support', icon: Wrench },
    ],
  },
  { label: 'Solutions', href: '/solutions' },
  { label: 'Industries', href: '/industries' },
  { label: 'Projects', href: '/projects' },
  {
    label: 'Resources',
    href: '/products',
    children: [
      { label: 'Products', href: '/products', description: 'Enterprise product catalogue with specs & datasheets', icon: Boxes },
      { label: 'Gallery', href: '/gallery', description: 'Project photos, installations & videos', icon: Images },
      { label: 'Downloads', href: '/downloads', description: 'Brochures, profiles, catalogues & datasheets', icon: Download },
    ],
  },
  { label: 'Company', href: '/company' },
  { label: 'Contact', href: '/contact' },
];

export const footerNav = {
  services: [
    { label: 'Building Management System', href: '/services/bms' },
    { label: 'IBMS', href: '/services/ibms' },
    { label: 'Building Automation', href: '/services/building-automation' },
    { label: 'HVAC Automation', href: '/services/hvac-automation' },
    { label: 'PLC Automation', href: '/services/plc-automation' },
    { label: 'SCADA', href: '/services/scada' },
  ],
  solutions: [
    { label: 'Smart Buildings', href: '/solutions' },
    { label: 'Industrial Automation', href: '/solutions' },
    { label: 'Energy Management', href: '/solutions' },
    { label: 'Security & Surveillance', href: '/solutions' },
    { label: 'IT Infrastructure', href: '/solutions' },
    { label: 'ELV Systems', href: '/solutions' },
  ],
  company: [
    { label: 'About Us', href: '/company' },
    { label: 'Projects', href: '/projects' },
    { label: 'Industries', href: '/industries' },
    { label: 'Products', href: '/products' },
    { label: 'Gallery', href: '/gallery' },
    { label: 'Downloads', href: '/downloads' },
    { label: 'Contact', href: '/contact' },
  ],
};

export const contactItems = [
  { icon: Phone, label: 'Call Us', value: company.phone, href: company.phoneHref },
  { icon: Mail, label: 'Email Us', value: company.email, href: company.emailHref },
  { icon: MapPin, label: 'Visit Us', value: 'Swasthya Vihar, New Delhi', href: '/contact' },
  { icon: Clock, label: 'Working Hours', value: company.hours, href: null },
];
