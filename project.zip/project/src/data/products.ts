export type Product = {
  id: string;
  name: string;
  category: string;
  description: string;
  image: string;
  specifications: { label: string; value: string }[];
  features: string[];
  applications: string[];
  datasheetUrl: string;
  brochureUrl: string;
};

export const products: Product[] = [
  {
    id: 'bms-controller',
    name: 'BMS Automation Controller',
    category: 'Building Automation',
    description:
      'Programmable DDC controller for HVAC, lighting and power management with open-protocol support and cloud connectivity.',
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    specifications: [
      { label: 'I/O Points', value: 'Up to 128' },
      { label: 'Protocols', value: 'BACnet, Modbus, OPC' },
      { label: 'CPU', value: '32-bit ARM' },
      { label: 'Memory', value: '128 MB Flash' },
      { label: 'Connectivity', value: 'Ethernet, Wi-Fi' },
      { label: 'Operating Temp', value: '-20 to 60 C' },
    ],
    features: [
      'Open-protocol BACnet/Modbus communication',
      'Web-based programming interface',
      'Cloud monitoring ready',
      'Built-in scheduling and logic engine',
      'Trend logging and alarm management',
    ],
    applications: ['Office Buildings', 'Hotels', 'Hospitals', 'Shopping Malls', 'Universities'],
    datasheetUrl: '#',
    brochureUrl: '#',
  },
  {
    id: 'scada-hmi-panel',
    name: 'SCADA HMI Touch Panel',
    category: 'Industrial Automation',
    description:
      '15-inch industrial HMI touch panel for SCADA visualisation, alarm management and real-time process control.',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    specifications: [
      { label: 'Display', value: '15" TFT Touch' },
      { label: 'Resolution', value: '1024x768' },
      { label: 'Protocols', value: 'OPC UA, Modbus, MQTT' },
      { label: 'Storage', value: '64 GB SSD' },
      { label: 'Connectivity', value: 'Ethernet, RS-485' },
      { label: 'Protection', value: 'IP65 Front' },
    ],
    features: [
      'Real-time process visualisation',
      'Alarm and event management',
      'Historian and trend analysis',
      'Recipe management',
      'Remote access via VPN',
    ],
    applications: ['Manufacturing Plants', 'Process Industries', 'Water Treatment', 'Power Plants'],
    datasheetUrl: '#',
    brochureUrl: '#',
  },
  {
    id: 'ip-camera',
    name: 'AI IP Surveillance Camera',
    category: 'Video Surveillance',
    description:
      '4K AI-powered IP camera with built-in video analytics for intrusion detection, people counting and perimeter protection.',
    image: 'https://images.pexels.com/photos/430208/pexels-photo-430208.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    specifications: [
      { label: 'Resolution', value: '4K (3840x2160)' },
      { label: 'Lens', value: '2.8-12mm Motorised' },
      { label: 'AI Analytics', value: 'Intrusion, Loitering, ANPR' },
      { label: 'Storage', value: 'Edge MicroSD 256GB' },
      { label: 'Connectivity', value: 'PoE, Wi-Fi' },
      { label: 'Protection', value: 'IP67, IK10' },
    ],
    features: [
      'Built-in AI video analytics',
      '4K Ultra HD recording',
      'Edge storage with cloud backup',
      'Night vision up to 50m',
      'Two-way audio',
    ],
    applications: ['Airports', 'Malls', 'Corporate Offices', 'Industrial Plants', 'Hospitals'],
    datasheetUrl: '#',
    brochureUrl: '#',
  },
  {
    id: 'access-control-panel',
    name: 'Access Control Panel',
    category: 'Security & Access',
    description:
      'Multi-door access control panel with biometric, card and mobile credential support, anti-passback and visitor management.',
    image: 'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    specifications: [
      { label: 'Doors', value: 'Up to 32' },
      { label: 'Credentials', value: 'Card, Biometric, Mobile' },
      { label: 'Users', value: '100,000' },
      { label: 'Connectivity', value: 'Ethernet, Wi-Fi' },
      { label: 'Integration', value: 'CCTV, Fire, BMS' },
      { label: 'Compliance', value: 'ISO 27001' },
    ],
    features: [
      'Multi-credential authentication',
      'Anti-passback and two-man rule',
      'Visitor and tenant management',
      'Real-time event alerts',
      'Integration with video and fire',
    ],
    applications: ['Corporate Offices', 'Hospitals', 'Banks', 'Airports', 'Data Centers'],
    datasheetUrl: '#',
    brochureUrl: '#',
  },
  {
    id: 'fire-alarm-panel',
    name: 'Addressable Fire Alarm Panel',
    category: 'Life Safety',
    description:
      'Addressable fire alarm control panel with multi-sensor detection, cause-and-effect programming and evacuation integration.',
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    specifications: [
      { label: 'Detection', value: 'Addressable' },
      { label: 'Devices', value: 'Up to 2,048' },
      { label: 'Loops', value: '8 Loops' },
      { label: 'Integration', value: 'BMS, PA, HVAC' },
      { label: 'Compliance', value: 'IS 2189, EN 54' },
      { label: 'Backup', value: '72h Battery' },
    ],
    features: [
      'Addressable multi-sensor detection',
      'Cause-and-effect programming',
      'Zoned evacuation messaging',
      'Integration with BMS and HVAC',
      '72-hour battery backup',
    ],
    applications: ['Hospitals', 'Hotels', 'Malls', 'Airports', 'Office Buildings'],
    datasheetUrl: '#',
    brochureUrl: '#',
  },
  {
    id: 'anpr-camera',
    name: 'ANPR Parking Camera',
    category: 'Parking & Barriers',
    description:
      'Automatic Number Plate Recognition camera for barrier-free parking entry, fee collection and vehicle tracking.',
    image: 'https://images.pexels.com/photos/905491/pexels-photo-905491.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    specifications: [
      { label: 'Recognition', value: '99.5% Accuracy' },
      { label: 'Speed', value: 'Up to 60 km/h' },
      { label: 'Plate Format', value: 'All Indian States' },
      { label: 'Connectivity', value: 'PoE, IP' },
      { label: 'Storage', value: 'Edge + Cloud' },
      { label: 'Protection', value: 'IP67' },
    ],
    features: [
      'Barrier-free parking access',
      'Real-time vehicle tracking',
      'Parking fee and validation',
      'Whitelist/blacklist management',
      'Cloud-based reporting',
    ],
    applications: ['Malls', 'Airports', 'Corporate Offices', 'Hospitals', 'Hotels'],
    datasheetUrl: '#',
    brochureUrl: '#',
  },
];

export const productCategories = [
  'All',
  ...Array.from(new Set(products.map((p) => p.category))),
];
