import type { LucideIcon } from 'lucide-react';
import {
  Building2, Network, Cpu, Flame, Thermometer, Radio, Gauge,
  ShieldCheck, Mic, Fingerprint, UserCheck, Car, ScanLine,
  Camera, Video, Wifi, Cable, Server, Database, Layers,
  Home, Activity, Cloud, Eye, Wrench, ClipboardCheck,
  DoorOpen, ParkingCircle, BarChart3, Zap, CircuitBoard,
  Monitor, Building, Lock, Bell, Phone, Mail, MapPin,
} from 'lucide-react';

export type ServiceCategory = {
  id: string;
  name: string;
  short: string;
  description: string;
  icon: LucideIcon;
  features: string[];
  benefits: string[];
};

export type ServiceGroup = {
  id: string;
  title: string;
  tagline: string;
  description: string;
  accent: string;
  services: ServiceCategory[];
};

export const serviceGroups: ServiceGroup[] = [
  {
    id: 'building-automation',
    title: 'Building Automation',
    tagline: 'Intelligent control for modern buildings',
    description:
      "Integrated systems that monitor, control and optimise your building's core operations — from HVAC to lighting, safety to security — on a single unified platform.",
    accent: 'brand',
    services: [
      {
        id: 'bms',
        name: 'Building Management System',
        short: 'BMS',
        description:
          'Centralised monitoring and control of mechanical, electrical and electromechanical services across a facility for energy efficiency, comfort and operational reliability.',
        icon: Building2,
        features: [
          'Centralised HVAC, lighting & power control',
          'Real-time equipment monitoring & alarms',
          'Energy dashboards & reporting',
          'Scheduling and occupancy-based automation',
        ],
        benefits: [
          'Up to 30% reduction in energy consumption',
          'Lower maintenance and operating costs',
          'Improved occupant comfort and safety',
        ],
      },
      {
        id: 'ibms',
        name: 'Integrated Building Management System',
        short: 'IBMS',
        description:
          'A single pane of glass that unifies BMS, fire, security, access, power and ELV systems into one interoperable platform with cross-system intelligence.',
        icon: Network,
        features: [
          'Single unified dashboard for all systems',
          'Cross-system cause-and-effect logic',
          'Open protocols (BACnet, Modbus, OPC)',
          'Centralised alarm and event management',
        ],
        benefits: [
          'Single-seat operator control',
          'Faster incident response',
          'Reduced integration complexity',
        ],
      },
      {
        id: 'building-automation',
        name: 'Building Automation',
        short: 'BA',
        description:
          'Programmable automation of building systems using DDC controllers and field devices to deliver comfort, efficiency and safety with minimal manual intervention.',
        icon: Cpu,
        features: [
          'DDC controllers & field instrumentation',
          'Programmable logic & sequences of operation',
          'Automated lighting and shading control',
          'BMS integration over open protocols',
        ],
        benefits: [
          'Hands-free building operations',
          'Consistent comfort conditions',
          'Reduced energy waste',
        ],
      },
      {
        id: 'hvac-automation',
        name: 'HVAC Automation',
        short: 'HVAC',
        description:
          'Precision control of heating, ventilation and air-conditioning systems for optimal thermal comfort, indoor air quality and energy performance.',
        icon: Thermometer,
        features: [
          'Chiller & AHU plant control',
          'VAV & FCU zone control',
          'Demand-controlled ventilation',
          'Optimised start/stop & sequencing',
        ],
        benefits: [
          'Improved indoor air quality',
          'Lower energy bills',
          'Extended equipment life',
        ],
      },
    ],
  },
  {
    id: 'industrial-automation',
    title: 'Industrial Automation',
    tagline: 'Process control & plant intelligence',
    description:
      'From shop-floor PLCs to enterprise SCADA, we engineer reliable automation that improves throughput, quality and safety across industrial operations.',
    accent: 'accent',
    services: [
      {
        id: 'plc-automation',
        name: 'PLC Automation',
        short: 'PLC',
        description:
          'Programmable Logic Controller-based control systems for machinery, production lines and industrial processes with deterministic, real-time performance.',
        icon: CircuitBoard,
        features: [
          'PLC programming & panel building',
          'Sensor and actuator integration',
          'HMI interfaces & recipe management',
          'Fault diagnostics & interlocks',
        ],
        benefits: [
          'Higher production consistency',
          'Reduced manual intervention',
          'Improved plant safety',
        ],
      },
      {
        id: 'scada',
        name: 'SCADA',
        short: 'SCADA',
        description:
          'Supervisory Control and Data Acquisition systems delivering real-time visualisation, historisation and control of distributed industrial processes.',
        icon: Monitor,
        features: [
          'Real-time process visualisation',
          'Historian & trend analysis',
          'Alarm & event management',
          'Multi-site remote monitoring',
        ],
        benefits: [
          'Plant-wide visibility',
          'Data-driven decisions',
          'Rapid fault detection',
        ],
      },
      {
        id: 'industrial-automation',
        name: 'Industrial Automation',
        short: 'IA',
        description:
          'End-to-end automation of manufacturing and process plants — from sensing and control to data acquisition and reporting.',
        icon: Cpu,
        features: [
          'Turnkey plant automation',
          'Motor control centres & drives',
          'Instrumentation & calibration',
          'MES & ERP integration',
        ],
        benefits: [
          'Increased throughput',
          'Improved product quality',
          'Lower operating cost',
        ],
      },
    ],
  },
  {
    id: 'energy',
    title: 'Energy Management',
    tagline: 'Measure. Analyse. Optimise.',
    description:
      'Data-driven energy intelligence that identifies waste, benchmarks performance and drives sustained reductions in consumption and cost.',
    accent: 'success',
    services: [
      {
        id: 'energy-management',
        name: 'Energy Management',
        short: 'EnMS',
        description:
          'Enterprise energy monitoring and analytics platform that tracks consumption across utilities, identifies anomalies and benchmarks performance.',
        icon: Zap,
        features: [
          'Multi-utility metering (electrical, water, gas)',
          'Real-time & historical analytics',
          'Benchmarking & KPI tracking',
          'Tariff & demand management',
        ],
        benefits: [
          'Identify energy waste fast',
          'Validate savings projects',
          'Support ISO 50001 compliance',
        ],
      },
      {
        id: 'building-energy-management',
        name: 'Building Energy Management',
        short: 'BEMS',
        description:
          'Intelligent building-level energy optimisation combining automation control with analytics to deliver verified, persistent energy savings.',
        icon: BarChart3,
        features: [
          'Consumption by zone & system',
          'Anomaly detection & alerts',
          'Automated demand response',
          'ESG & sustainability reporting',
        ],
        benefits: [
          'Verified energy savings',
          'Lower carbon footprint',
          'Improved asset performance',
        ],
      },
    ],
  },
  {
    id: 'life-safety',
    title: 'Life Safety & Security',
    tagline: 'Protecting people, property & assets',
    description:
      'Integrated life-safety and security systems engineered to detect, alert and respond — protecting occupants, property and operations around the clock.',
    accent: 'error',
    services: [
      {
        id: 'fire-alarm',
        name: 'Fire Alarm System',
        short: 'FAS',
        description:
          'Addressable fire detection and alarm systems with early-warning sensors, cause-and-effect programming and integration to BMS and public address.',
        icon: Flame,
        features: [
          'Addressable detection & zoning',
          'Smoke, heat & multi-sensor detectors',
          'Cause-and-effect programming',
          'Integration with BMS & HVAC',
        ],
        benefits: [
          'Early reliable detection',
          'Faster evacuation',
          'Code-compliant life safety',
        ],
      },
      {
        id: 'public-address',
        name: 'Public Address System',
        short: 'PA',
        description:
          'Professional public address and voice evacuation systems for clear announcements, background music and emergency voice messaging.',
        icon: Mic,
        features: [
          'Zoned paging & announcements',
          'Voice evacuation messaging',
          'Background music distribution',
          'Fire alarm integration',
        ],
        benefits: [
          'Clear communication',
          'Code-compliant evacuation',
          'Enhanced occupant experience',
        ],
      },
      {
        id: 'access-control',
        name: 'Access Control',
        short: 'AC',
        description:
          'Electronic access control systems managing entry to buildings, floors and zones with credential-based authentication and audit trails.',
        icon: Lock,
        features: [
          'Card, fob & mobile credentials',
          'Anti-passback & two-man rule',
          'Visitor & tenant management',
          'Integration with video & fire',
        ],
        benefits: [
          'Stronger physical security',
          'Full entry audit trail',
          'Reduced unauthorised access',
        ],
      },
      {
        id: 'visitor-management',
        name: 'Visitor Management',
        short: 'VMS',
        description:
          'Digital visitor management for secure, professional check-in with ID capture, host notifications and visitor analytics.',
        icon: UserCheck,
        features: [
          'Self-service kiosk check-in',
          'ID scanning & photo capture',
          'Host notifications & approvals',
          'Visitor analytics & reports',
        ],
        benefits: [
          'Professional first impression',
          'Improved front-desk efficiency',
          'Secure visitor audit trail',
        ],
      },
      {
        id: 'biometric',
        name: 'Biometric System',
        short: 'Bio',
        description:
          'Biometric authentication for time-attendance and access control using fingerprint, face and iris recognition with anti-spoofing.',
        icon: Fingerprint,
        features: [
          'Fingerprint, face & iris recognition',
          'Time & attendance tracking',
          'Anti-spoofing & liveness detection',
          'Payroll-ready attendance exports',
        ],
        benefits: [
          'Eliminate buddy punching',
          'Accurate attendance records',
          'Frictionless authentication',
        ],
      },
    ],
  },
  {
    id: 'parking',
    title: 'Parking & Barriers',
    tagline: 'Smart, secure parking control',
    description:
      'Automated parking and barrier solutions that streamline vehicle entry, improve security and deliver real-time occupancy intelligence.',
    accent: 'warning',
    services: [
      {
        id: 'boom-barrier',
        name: 'Boom Barrier',
        short: 'BB',
        description:
          'Robust boom barrier systems for controlled vehicle access at gates, parking entries and toll plazas with integration to access and ANPR.',
        icon: Car,
        features: [
          'Automatic boom barrier gates',
          'RFID & proximity card integration',
          'Loop detector & safety sensors',
          'Remote & manual override',
        ],
        benefits: [
          'Controlled vehicle access',
          'Improved gate security',
          'Smooth traffic flow',
        ],
      },
      {
        id: 'anpr-parking',
        name: 'ANPR Parking',
        short: 'ANPR',
        description:
          'Automatic Number Plate Recognition for barrier-free parking entry, fee collection and vehicle tracking with high-accuracy LPR cameras.',
        icon: ScanLine,
        features: [
          'LPR camera-based entry/exit',
          'Barrier-free parking access',
          'Real-time vehicle tracking',
          'Parking fee & validation',
        ],
        benefits: [
          'Frictionless parking entry',
          'Reduced gate congestion',
          'Improved revenue collection',
        ],
      },
      {
        id: 'parking-guidance',
        name: 'Parking Guidance',
        short: 'PGS',
        description:
          'Sensor and camera-based parking guidance systems that guide drivers to available bays and deliver real-time occupancy data.',
        icon: ParkingCircle,
        features: [
          'Ultrasonic bay sensors',
          'Zone & level guidance signage',
          'Real-time occupancy dashboard',
          'Mobile app integration',
        ],
        benefits: [
          'Faster parking for visitors',
          'Reduced garage congestion',
          'Optimised space utilisation',
        ],
      },
    ],
  },
  {
    id: 'surveillance',
    title: 'Video Surveillance',
    tagline: 'See everything. Miss nothing.',
    description:
      'Enterprise-grade video surveillance and analytics that deliver proactive security, operational insight and forensic evidence across your facilities.',
    accent: 'brand',
    services: [
      {
        id: 'cctv-surveillance',
        name: 'CCTV Surveillance',
        short: 'CCTV',
        description:
          'High-definition IP video surveillance systems with centralised recording, remote monitoring and enterprise video management.',
        icon: Camera,
        features: [
          'IP & multi-sensor cameras',
          'Centralised VMS & NVR storage',
          'Remote live & playback viewing',
          'Edge & central recording',
        ],
        benefits: [
          '24/7 security coverage',
          'Strong forensic evidence',
          'Remote situational awareness',
        ],
      },
      {
        id: 'video-analytics',
        name: 'Video Analytics',
        short: 'VA',
        description:
          'AI-powered video analytics for intrusion detection, people counting, perimeter protection and operational intelligence.',
        icon: Video,
        features: [
          'Intrusion & perimeter detection',
          'People counting & heatmaps',
          'Loitering & object left detection',
          'ANPR & face recognition',
        ],
        benefits: [
          'Proactive threat detection',
          'Reduced false alarms',
          'Actionable operational insight',
        ],
      },
    ],
  },
  {
    id: 'it-infrastructure',
    title: 'IT Infrastructure',
    tagline: 'The backbone of smart buildings',
    description:
      'Resilient, scalable IT infrastructure — structured cabling, networking, data centres and server rooms — engineered to power mission-critical systems.',
    accent: 'ink',
    services: [
      {
        id: 'networking',
        name: 'Networking',
        short: 'NET',
        description:
          'Enterprise network design, deployment and management — LAN, WLAN and segmentation — for secure, high-performance connectivity.',
        icon: Wifi,
        features: [
          'LAN, WLAN & VLAN design',
          'Network segmentation & security',
          'High-availability core switching',
          'SD-WAN & remote access',
        ],
        benefits: [
          'Reliable connectivity',
          'Strong network security',
          'Scalable for growth',
        ],
      },
      {
        id: 'structured-cabling',
        name: 'Structured Cabling',
        short: 'CAB',
        description:
          'Standards-compliant structured cabling for voice, data and building systems with certified performance and labelling.',
        icon: Cable,
        features: [
          'Cat6/Cat6A & fibre optic cabling',
          'Patch panels & cable management',
          'Certified testing & labelling',
          'Cable tray & pathway systems',
        ],
        benefits: [
          'Future-proof infrastructure',
          'Reduced downtime',
          'Clean, manageable plant',
        ],
      },
      {
        id: 'data-center',
        name: 'Data Center',
        short: 'DC',
        description:
          'Turnkey data centre design and build — power, cooling, racks, security and monitoring — for reliable, efficient operations.',
        icon: Server,
        features: [
          'Rack & aisle containment',
          'Precision cooling & power',
          'DCIM monitoring & alerts',
          'Fire suppression & security',
        ],
        benefits: [
          'High availability',
          'Optimised cooling efficiency',
          'Centralised monitoring',
        ],
      },
      {
        id: 'server-room',
        name: 'Server Room Solutions',
        short: 'SR',
        description:
          'Server room design and fit-out with environmental control, power backup, security and remote monitoring for SMB and enterprise.',
        icon: Database,
        features: [
          'Environmental monitoring',
          'UPS & power backup',
          'Access control & CCTV',
          'Fire detection & suppression',
        ],
        benefits: [
          'Protected IT assets',
          'Uptime assurance',
          'Remote oversight',
        ],
      },
    ],
  },
  {
    id: 'elv-iot',
    title: 'ELV & Smart Systems',
    tagline: 'Connected. Intelligent. Future-ready.',
    description:
      'Extra-Low-Voltage systems, home automation and Industrial IoT that connect buildings, assets and people into a single intelligent ecosystem.',
    accent: 'success',
    services: [
      {
        id: 'elv-systems',
        name: 'ELV Systems',
        short: 'ELV',
        description:
          'Complete Extra-Low-Voltage system design and integration — security, safety, communications and automation — on a unified backbone.',
        icon: Layers,
        features: [
          'CCTV, access & fire integration',
          'PA & structured cabling',
          'Centralised ELV room design',
          'Open-protocol integration',
        ],
        benefits: [
          'Single integrated platform',
          'Reduced cabling complexity',
          'Future-ready infrastructure',
        ],
      },
      {
        id: 'home-automation',
        name: 'Home Automation',
        short: 'HA',
        description:
          'Smart home automation for lighting, climate, shading, entertainment and security — controlled by app, voice or schedule.',
        icon: Home,
        features: [
          'Lighting & scene control',
          'Climate & shading automation',
          'Voice & app control',
          'Security & video doorbells',
        ],
        benefits: [
          'Effortless comfort & convenience',
          'Energy savings',
          'Enhanced home security',
        ],
      },
      {
        id: 'industrial-iot',
        name: 'Industrial IoT',
        short: 'IIoT',
        description:
          'Industrial IoT platforms that connect assets, sensors and systems to the cloud for real-time insight and predictive maintenance.',
        icon: Activity,
        features: [
          'Edge gateways & sensor networks',
          'Cloud data ingestion & storage',
          'Predictive maintenance analytics',
          'Digital twin & dashboards',
        ],
        benefits: [
          'Asset-level visibility',
          'Reduced unplanned downtime',
          'Data-driven optimisation',
        ],
      },
      {
        id: 'cloud-monitoring',
        name: 'Cloud Monitoring',
        short: 'Cloud',
        description:
          'Cloud-based monitoring of building and industrial systems with remote dashboards, alerts and reporting from anywhere.',
        icon: Cloud,
        features: [
          'Multi-site cloud dashboards',
          'Real-time alerts & notifications',
          'Historical reporting & export',
          'Role-based access control',
        ],
        benefits: [
          'Monitor from anywhere',
          'Centralised multi-site oversight',
          'Faster incident response',
        ],
      },
      {
        id: 'remote-monitoring',
        name: 'Remote Monitoring',
        short: 'RMS',
        description:
          '24/7 remote monitoring services for building and industrial systems with NOC support, alarm management and escalation.',
        icon: Eye,
        features: [
          '24/7 NOC monitoring',
          'Alarm management & escalation',
          'Remote diagnostics & resets',
          'Monthly performance reports',
        ],
        benefits: [
          'Round-the-clock oversight',
          'Faster issue resolution',
          'Reduced on-site visits',
        ],
      },
    ],
  },
  {
    id: 'support',
    title: 'Support & Maintenance',
    tagline: 'Lifetime performance, guaranteed',
    description:
      'Comprehensive maintenance and support services that keep your systems performing at their best — today and for years to come.',
    accent: 'accent',
    services: [
      {
        id: 'amc-services',
        name: 'AMC Services',
        short: 'AMC',
        description:
          'Annual Maintenance Contracts covering preventive and corrective maintenance, priority support and spare-parts management.',
        icon: Wrench,
        features: [
          'Scheduled preventive maintenance',
          'Priority response & SLAs',
          'Genuine spare-parts management',
          'Dedicated account engineer',
        ],
        benefits: [
          'Predictable maintenance costs',
          'Minimised downtime',
          'Extended system life',
        ],
      },
      {
        id: 'preventive-maintenance',
        name: 'Preventive Maintenance',
        short: 'PM',
        description:
          'Scheduled preventive maintenance programmes that catch issues early, optimise performance and extend equipment life.',
        icon: ClipboardCheck,
        features: [
          'Inspection & calibration schedules',
          'Firmware & software updates',
          'Health-check reports',
          'Performance benchmarking',
        ],
        benefits: [
          'Fewer breakdowns',
          'Optimised performance',
          'Lower lifecycle cost',
        ],
      },
    ],
  },
];

export const allServices: ServiceCategory[] = serviceGroups.flatMap((g) => g.services);

export function getServiceById(id: string): ServiceCategory | undefined {
  return allServices.find((s) => s.id === id);
}

export function getGroupByServiceId(id: string): ServiceGroup | undefined {
  return serviceGroups.find((g) => g.services.some((s) => s.id === id));
}
