export type GalleryItem = {
  id: string;
  title: string;
  category: 'Project Photos' | 'Installation Photos' | 'Videos';
  image: string;
  description: string;
  span?: 'tall' | 'wide' | 'normal';
};

export const galleryItems: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Corporate Tower IBMS Installation',
    category: 'Installation Photos',
    image: 'https://images.pexels.com/photos/302769/pexels-photo-302769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'IBMS control room setup with unified monitoring dashboards.',
    span: 'wide',
  },
  {
    id: 'g2',
    title: 'Manufacturing Plant SCADA',
    category: 'Project Photos',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'SCADA visualisation for a precision manufacturing line.',
    span: 'tall',
  },
  {
    id: 'g3',
    title: 'Data Center Build',
    category: 'Project Photos',
    image: 'https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'Tier-III data centre with precision cooling and DCIM.',
    span: 'normal',
  },
  {
    id: 'g4',
    title: 'Hospital HVAC Automation',
    category: 'Installation Photos',
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'HVAC plant control panel installation for a hospital.',
    span: 'normal',
  },
  {
    id: 'g5',
    title: 'Mall Parking Guidance',
    category: 'Project Photos',
    image: 'https://images.pexels.com/photos/5650026/pexels-photo-5650026.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'Bay-level parking guidance with real-time occupancy.',
    span: 'wide',
  },
  {
    id: 'g6',
    title: 'Airport Surveillance Tour',
    category: 'Videos',
    image: 'https://images.pexels.com/photos/9558760/pexels-photo-9558760.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'Video walkthrough of airport CCTV and ANPR deployment.',
    span: 'tall',
  },
  {
    id: 'g7',
    title: 'Structured Cabling Deployment',
    category: 'Installation Photos',
    image: 'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'Cat6A structured cabling with patch panel management.',
    span: 'normal',
  },
  {
    id: 'g8',
    title: 'Fire Alarm Commissioning',
    category: 'Installation Photos',
    image: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'Addressable fire alarm panel commissioning and testing.',
    span: 'normal',
  },
  {
    id: 'g9',
    title: 'Smart Building Walkthrough',
    category: 'Videos',
    image: 'https://images.pexels.com/photos/261101/pexels-photo-261101.jpeg?auto=compress&cs=tinysrgb&w=1260&h=800&dpr=2',
    description: 'Video tour of a fully automated smart hotel building.',
    span: 'wide',
  },
];

export const galleryCategories = ['All', 'Project Photos', 'Installation Photos', 'Videos'] as const;
