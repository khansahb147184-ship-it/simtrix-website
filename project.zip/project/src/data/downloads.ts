export type DownloadItem = {
  id: string;
  title: string;
  description: string;
  category: 'Brochure' | 'Company Profile' | 'Product Catalogue' | 'Datasheet';
  fileSize: string;
  fileType: 'PDF' | 'DOC' | 'ZIP';
  url: string;
  icon: string;
};

export const downloads: DownloadItem[] = [
  {
    id: 'company-brochure',
    title: 'Company Brochure',
    description: 'Complete overview of Simtrix Infotech services, solutions and capabilities.',
    category: 'Brochure',
    fileSize: '2.4 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'FileText',
  },
  {
    id: 'company-profile',
    title: 'Company Profile',
    description: 'Detailed company profile with project portfolio, certifications and case studies.',
    category: 'Company Profile',
    fileSize: '5.1 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'Building2',
  },
  {
    id: 'product-catalogue',
    title: 'Product Catalogue',
    description: 'Full catalogue of BMS controllers, SCADA panels, cameras and access control systems.',
    category: 'Product Catalogue',
    fileSize: '8.7 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'Boxes',
  },
  {
    id: 'bms-datasheet',
    title: 'BMS Controller Datasheet',
    description: 'Technical specifications for the BMS Automation Controller.',
    category: 'Datasheet',
    fileSize: '1.2 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'Cpu',
  },
  {
    id: 'scada-datasheet',
    title: 'SCADA HMI Datasheet',
    description: 'Technical specifications for the SCADA HMI Touch Panel.',
    category: 'Datasheet',
    fileSize: '0.9 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'Monitor',
  },
  {
    id: 'camera-datasheet',
    title: 'AI IP Camera Datasheet',
    description: 'Technical specifications for the AI IP Surveillance Camera.',
    category: 'Datasheet',
    fileSize: '1.5 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'Camera',
  },
  {
    id: 'access-datasheet',
    title: 'Access Control Datasheet',
    description: 'Technical specifications for the multi-door Access Control Panel.',
    category: 'Datasheet',
    fileSize: '1.1 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'Lock',
  },
  {
    id: 'fire-datasheet',
    title: 'Fire Alarm Panel Datasheet',
    description: 'Technical specifications for the Addressable Fire Alarm Panel.',
    category: 'Datasheet',
    fileSize: '1.3 MB',
    fileType: 'PDF',
    url: '#',
    icon: 'Flame',
  },
];

export const downloadCategories = ['All', 'Brochure', 'Company Profile', 'Product Catalogue', 'Datasheet'] as const;
