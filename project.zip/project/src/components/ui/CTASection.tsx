import { Link } from 'react-router-dom';
import { ArrowRight, Phone } from 'lucide-react';
import { Reveal } from './Reveal';
import { company } from '@/data/company';

type CTASectionProps = {
  title?: string;
  subtitle?: string;
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
};

export function CTASection({
  title = 'Ready to build something smart?',
  subtitle = "Let's talk about how Simtrix can engineer, integrate and optimise your building or industrial systems.",
  primaryLabel = 'Start a Project',
  primaryHref = '/contact',
  secondaryLabel = 'Call Us',
}: CTASectionProps) {
  return (
    <section className="relative overflow-hidden bg-ink-950 py-20 lg:py-28">
      <div className="absolute inset-0 grid-bg-dark opacity-40" />
      <div className="absolute -top-40 left-1/2 h-96 w-[40rem] -translate-x-1/2 rounded-full bg-brand-600/20 blur-3xl" />
      <div className="absolute -bottom-40 right-0 h-96 w-96 rounded-full bg-accent-500/10 blur-3xl" />

      <div className="container-page relative">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <span className="eyebrow !text-brand-300">
              <span className="h-px w-6 bg-current opacity-60" />
              Let's Connect
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl lg:text-5xl">
              {title}
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-lg text-ink-300">{subtitle}</p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link to={primaryHref} className="btn-primary group">
                {primaryLabel}
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <a href={company.phoneHref} className="btn-light group">
                <Phone className="h-4 w-4" />
                {secondaryLabel}
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
