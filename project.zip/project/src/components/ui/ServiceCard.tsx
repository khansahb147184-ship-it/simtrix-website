import { Link } from 'react-router-dom';
import { ArrowUpRight, Check } from 'lucide-react';
import type { ServiceCategory } from '@/data/services';
import { Reveal } from './Reveal';

type ServiceCardProps = {
  service: ServiceCategory;
  variant?: 'default' | 'compact';
  index?: number;
};

export function ServiceCard({ service, variant = 'default', index = 0 }: ServiceCardProps) {
  const Icon = service.icon;

  if (variant === 'compact') {
    return (
      <Reveal delay={index * 60}>
        <Link
          to={`/services/${service.id}`}
          className="group flex h-full flex-col rounded-2xl border border-ink-100 bg-white p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-card-hover"
        >
          <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition-colors group-hover:bg-brand-600 group-hover:text-white">
            <Icon className="h-6 w-6" />
          </div>
          <h3 className="font-display text-lg font-semibold text-ink-900">{service.name}</h3>
          <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-500">{service.description}</p>
          <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-600 opacity-0 transition-opacity group-hover:opacity-100">
            Learn more <ArrowUpRight className="h-4 w-4" />
          </span>
        </Link>
      </Reveal>
    );
  }

  return (
    <Reveal delay={index * 80}>
      <Link
        to={`/services/${service.id}`}
        className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-ink-100 bg-white p-8 shadow-card transition-all duration-500 hover:-translate-y-2 hover:border-brand-200 hover:shadow-card-hover"
      >
        {/* Hover gradient backdrop */}
        <div className="absolute inset-0 bg-gradient-to-br from-brand-50/0 via-brand-50/0 to-brand-50/0 opacity-0 transition-opacity duration-500 group-hover:from-brand-50/60 group-hover:to-accent-50/30 group-hover:opacity-100" />

        <div className="relative">
          <div className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-lg shadow-brand-600/30 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3">
            <Icon className="h-7 w-7" />
          </div>

          <span className="absolute right-0 top-0 inline-flex h-10 w-10 items-center justify-center rounded-full bg-ink-50 text-ink-400 transition-all duration-300 group-hover:bg-brand-600 group-hover:text-white group-hover:rotate-45">
            <ArrowUpRight className="h-5 w-5" />
          </span>

          <h3 className="font-display text-xl font-bold text-ink-900">{service.name}</h3>
          <p className="mt-3 text-sm leading-relaxed text-ink-500">{service.description}</p>

          <ul className="mt-6 space-y-2">
            {service.features.slice(0, 3).map((f) => (
              <li key={f} className="flex items-start gap-2 text-sm text-ink-600">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-success-500" />
                {f}
              </li>
            ))}
          </ul>
        </div>
      </Link>
    </Reveal>
  );
}
