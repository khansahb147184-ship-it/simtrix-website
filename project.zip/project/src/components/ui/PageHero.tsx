import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, ArrowLeft } from 'lucide-react';
import { Reveal } from './Reveal';

type Breadcrumb = { label: string; href?: string };

type PageHeroProps = {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  breadcrumbs?: Breadcrumb[];
  children?: ReactNode;
};

export function PageHero({ eyebrow, title, subtitle, breadcrumbs = [], children }: PageHeroProps) {
  return (
    <section className="relative overflow-hidden bg-ink-950 pt-32 pb-20 sm:pt-36 lg:pt-40 lg:pb-24">
      {/* Background layers */}
      <div className="absolute inset-0 grid-bg-dark opacity-60" />
      <div className="absolute inset-0 bg-gradient-to-b from-ink-950/40 via-ink-950/70 to-ink-950" />
      <div className="absolute -top-32 -right-32 h-96 w-96 rounded-full bg-brand-600/20 blur-3xl animate-pulse-slow" />
      <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-accent-500/10 blur-3xl animate-pulse-slow" />

      <div className="container-page relative">
        {breadcrumbs.length > 0 && (
          <Reveal>
            <nav className="mb-8 flex items-center gap-1.5 text-sm text-ink-400">
              <Link to="/" className="transition-colors hover:text-white">
                Home
              </Link>
              {breadcrumbs.map((b) => (
                <span key={b.label} className="flex items-center gap-1.5">
                  <ChevronRight className="h-3.5 w-3.5 text-ink-600" />
                  {b.href ? (
                    <Link to={b.href} className="transition-colors hover:text-white">
                      {b.label}
                    </Link>
                  ) : (
                    <span className="text-white">{b.label}</span>
                  )}
                </span>
              ))}
            </nav>
          </Reveal>
        )}

        {eyebrow && (
          <Reveal delay={60}>
            <span className="eyebrow !text-brand-300">
              <span className="h-px w-6 bg-current opacity-60" />
              {eyebrow}
            </span>
          </Reveal>
        )}

        <Reveal delay={120}>
          <h1 className="mt-4 max-w-4xl font-display text-4xl font-bold leading-[1.05] text-white sm:text-5xl lg:text-6xl">
            {title}
          </h1>
        </Reveal>

        {subtitle && (
          <Reveal delay={200}>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-ink-300">{subtitle}</p>
          </Reveal>
        )}

        {children && (
          <Reveal delay={280}>
            <div className="mt-8">{children}</div>
          </Reveal>
        )}
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-brand-500/40 to-transparent" />
    </section>
  );
}

export function BackLink({ to, label }: { to: string; label: string }) {
  return (
    <Link
      to={to}
      className="group inline-flex items-center gap-2 text-sm font-semibold text-ink-600 transition-colors hover:text-brand-600"
    >
      <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
      {label}
    </Link>
  );
}
