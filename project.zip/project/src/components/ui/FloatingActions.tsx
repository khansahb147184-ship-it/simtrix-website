import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, Mail, ArrowUp, MessageCircle, X } from 'lucide-react';
import { company } from '@/data/company';

export function FloatingActions() {
  const [showTop, setShowTop] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const whatsappUrl = `https://wa.me/919355026226?text=${encodeURIComponent(
    'Hello Simtrix Infotech, I would like to enquire about your services.',
  )}`;

  const actions = [
    {
      label: 'Call Us',
      icon: Phone,
      href: company.phoneHref,
      bg: 'bg-brand-600 hover:bg-brand-700',
    },
    {
      label: 'Email Us',
      icon: Mail,
      href: company.emailHref,
      bg: 'bg-ink-800 hover:bg-ink-900',
    },
    {
      label: 'WhatsApp',
      icon: MessageCircle,
      href: whatsappUrl,
      bg: 'bg-success-600 hover:bg-success-700',
    },
  ];

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      {/* Back to top */}
      <AnimatePresence>
        {showTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.6 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.6 }}
            transition={{ duration: 0.2 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            aria-label="Back to top"
            className="flex h-11 w-11 items-center justify-center rounded-full bg-ink-900 text-white shadow-lg shadow-ink-900/30 transition-colors hover:bg-ink-800"
          >
            <ArrowUp className="h-5 w-5" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Expanded action buttons */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-col items-end gap-2 overflow-hidden"
          >
            {actions.map((a, i) => (
              <motion.a
                key={a.label}
                href={a.href}
                target={a.href.startsWith('http') ? '_blank' : undefined}
                rel={a.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0, transition: { delay: i * 0.06 } }}
                exit={{ opacity: 0, x: 20, transition: { delay: (actions.length - i) * 0.04 } }}
                className="group flex items-center gap-2"
              >
                <span className="rounded-lg bg-ink-900/90 px-3 py-1.5 text-xs font-semibold text-white shadow-lg backdrop-blur transition-opacity group-hover:opacity-100 sm:opacity-0">
                  {a.label}
                </span>
                <span className={`flex h-11 w-11 items-center justify-center rounded-full ${a.bg} text-white shadow-lg transition-transform group-hover:scale-110`}>
                  <a.icon className="h-5 w-5" />
                </span>
              </motion.a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggle button */}
      <motion.button
        onClick={() => setExpanded((v) => !v)}
        whileTap={{ scale: 0.9 }}
        aria-label="Quick contact"
        className="relative flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-xl shadow-brand-600/40 ring-2 ring-white/20"
      >
        <AnimatePresence mode="wait">
          {expanded ? (
            <motion.span key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X className="h-6 w-6" />
            </motion.span>
          ) : (
            <motion.span key="open" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <MessageCircle className="h-6 w-6" />
            </motion.span>
          )}
        </AnimatePresence>
        {!expanded && (
          <span className="absolute -right-0.5 -top-0.5 flex h-3.5 w-3.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent-400 opacity-75" />
            <span className="relative inline-flex h-3.5 w-3.5 rounded-full bg-accent-500 ring-2 ring-white" />
          </span>
        )}
      </motion.button>
    </div>
  );
}
