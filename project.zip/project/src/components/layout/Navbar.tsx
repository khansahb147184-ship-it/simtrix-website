import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, Phone, ArrowRight } from 'lucide-react';
import { navLinks, company } from '@/data/company';

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const location = useLocation();
  const megaRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setMegaOpen(false);
    setMobileServicesOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/90 shadow-card backdrop-blur-xl' : 'bg-white/0'
      }`}
    >
      <nav className="container-page flex h-[72px] items-center justify-between">
        {/* Logo */}
        <Link to="/" className="group flex items-center gap-3" aria-label="Simtrix Infotech home">
          <span className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-ink-950 text-white shadow-lg transition-transform group-hover:scale-105">
            <svg viewBox="0 0 64 64" className="h-7 w-7" fill="none">
              <path d="M20 44V20l24 24V20" stroke="#338eff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="32" cy="32" r="3" fill="#fbbf24" />
            </svg>
            <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-accent-400 ring-2 ring-white" />
          </span>
          <span className="flex flex-col leading-none">
            <span className={`font-display text-lg font-bold tracking-tight ${scrolled ? 'text-ink-900' : 'text-ink-900'}`}>
              Simtrix
            </span>
            <span className="text-[10px] font-medium uppercase tracking-[0.2em] text-ink-400">
              Infotech
            </span>
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden items-center gap-1 lg:flex">
          {navLinks.map((link) =>
            link.children ? (
              <div
                key={link.label}
                className="relative"
                onMouseEnter={() => setMegaOpen(true)}
                onMouseLeave={() => setMegaOpen(false)}
              >
                <button
                  className={`flex items-center gap-1 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                    location.pathname.startsWith('/services')
                      ? 'text-brand-700'
                      : scrolled
                      ? 'text-ink-700 hover:text-brand-700'
                      : 'text-ink-700 hover:text-brand-700'
                  }`}
                >
                  {link.label}
                  <ChevronDown className={`h-4 w-4 transition-transform ${megaOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* Mega menu */}
                <div
                  ref={megaRef}
                  className={`absolute left-1/2 top-full w-[44rem] -translate-x-1/2 pt-3 transition-all duration-300 ${
                    megaOpen ? 'visible opacity-100' : 'invisible opacity-0'
                  }`}
                >
                  <div className="overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-card-hover">
                    <div className="grid grid-cols-2 gap-1 p-4">
                      {link.children.map((child) => {
                        const Icon = child.icon;
                        return (
                          <Link
                            key={child.href}
                            to={child.href}
                            className="group flex items-start gap-3 rounded-xl p-3 transition-colors hover:bg-ink-50"
                          >
                            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-600 transition-colors group-hover:bg-brand-600 group-hover:text-white">
                              <Icon className="h-5 w-5" />
                            </span>
                            <span className="min-w-0">
                              <span className="block text-sm font-semibold text-ink-900">{child.label}</span>
                              <span className="block truncate text-xs text-ink-400">{child.description}</span>
                            </span>
                          </Link>
                        );
                      })}
                    </div>
                    <Link
                      to="/services"
                      className="flex items-center justify-between border-t border-ink-100 bg-ink-50/50 px-5 py-3 text-sm font-semibold text-brand-700 transition-colors hover:bg-brand-50"
                    >
                      View all services
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ) : (
              <NavLink
                key={link.label}
                to={link.href}
                end={link.href === '/'}
                className={({ isActive }) =>
                  `rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                    isActive ? 'text-brand-700' : 'text-ink-700 hover:text-brand-700'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ),
          )}
        </div>

        {/* CTA */}
        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={company.phoneHref}
            className="flex items-center gap-2 text-sm font-semibold text-ink-700 transition-colors hover:text-brand-700"
          >
            <Phone className="h-4 w-4" />
            {company.phone}
          </a>
          <Link to="/contact" className="btn-primary">
            Get a Quote
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => setMobileOpen((v) => !v)}
          className="flex h-10 w-10 items-center justify-center rounded-lg text-ink-800 transition-colors hover:bg-ink-100 lg:hidden"
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 top-[72px] z-40 overflow-y-auto bg-white transition-transform duration-300 lg:hidden ${
          mobileOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="container-page py-6">
          <div className="flex flex-col gap-1">
            {navLinks.map((link) =>
              link.children ? (
                <div key={link.label}>
                  <button
                    onClick={() => setMobileServicesOpen((v) => !v)}
                    className="flex w-full items-center justify-between rounded-xl px-4 py-3 text-base font-semibold text-ink-800 hover:bg-ink-50"
                  >
                    {link.label}
                    <ChevronDown className={`h-5 w-5 transition-transform ${mobileServicesOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {mobileServicesOpen && (
                    <div className="ml-3 mt-1 flex flex-col gap-0.5 border-l-2 border-ink-100 pl-3">
                      <Link
                        to="/services"
                        className="rounded-lg px-4 py-2.5 text-sm font-semibold text-brand-700 hover:bg-brand-50"
                      >
                        View all services
                      </Link>
                      {link.children.map((child) => {
                        const Icon = child.icon;
                        return (
                          <Link
                            key={child.href}
                            to={child.href}
                            className="flex items-center gap-3 rounded-lg px-4 py-2.5 text-sm text-ink-600 hover:bg-ink-50"
                          >
                            <Icon className="h-4 w-4 text-brand-500" />
                            {child.label}
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              ) : (
                <NavLink
                  key={link.label}
                  to={link.href}
                  end={link.href === '/'}
                  className={({ isActive }) =>
                    `rounded-xl px-4 py-3 text-base font-semibold transition-colors ${
                      isActive ? 'bg-brand-50 text-brand-700' : 'text-ink-800 hover:bg-ink-50'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ),
            )}
          </div>

          <div className="mt-6 flex flex-col gap-3 border-t border-ink-100 pt-6">
            <Link to="/contact" className="btn-primary w-full">
              Get a Quote
              <ArrowRight className="h-4 w-4" />
            </Link>
            <a href={company.phoneHref} className="flex items-center justify-center gap-2 text-sm font-semibold text-ink-700">
              <Phone className="h-4 w-4" />
              {company.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Backdrop when mobile open */}
      {mobileOpen && <div className="fixed inset-0 top-[72px] z-30 bg-ink-950/20 lg:hidden" onClick={() => setMobileOpen(false)} />}
    </header>
  );
}
