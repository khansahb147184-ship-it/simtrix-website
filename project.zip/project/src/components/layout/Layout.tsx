import type { ReactNode } from 'react';
import { Outlet } from 'react-router-dom';
import { TopBar } from './TopBar';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { ScrollToTop } from '@/components/ui/ScrollToTop';
import { LoadingScreen } from '@/components/ui/LoadingScreen';
import { FloatingActions } from '@/components/ui/FloatingActions';

export function Layout({ children }: { children?: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <LoadingScreen />
      <ScrollToTop />
      <TopBar />
      <Navbar />
      <main className="flex-1">{children ?? <Outlet />}</main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
