import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, ArrowRight, Linkedin, Facebook, Twitter, Youtube } from 'lucide-react';
import { company, footerNav } from '@/data/company';

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative overflow-hidden bg-ink-950 text-ink-300">
      <div className="absolute inset-0 grid-bg-dark opacity-30" />
      <div className="absolute -top-32 left-1/4 h-64 w-64 rounded-full bg-brand-600/10 blur-3xl" />

      <div className="container-page relative">
        {/* Top CTA strip */}
        <div className="flex flex-col items-center justify-between gap-6 border-b border-white/10 py-12 lg:flex-row">
          <div>
            <h3 className="font-display text-2xl font-bold text-white sm:text-3xl">
              Let's engineer your next smart project
            </h3>
            <p className="mt-2 text-ink-400">Talk to our team about BMS, automation, ELV and smart infrastructure.</p>
          </div>
          <Link to="/contact" className="btn-primary shrink-0">
            Get a Quote <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {/* Main footer */}
        <div className="grid grid-cols-2 gap-10 py-16 md:grid-cols-3 lg:grid-cols-12">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-4">
            <Link to="/" className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/5 ring-1 ring-white/10">
                <svg viewBox="0 0 64 64" className="h-7 w-7" fill="none">
                  <path d="M20 44V20l24 24V20" stroke="#338eff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
                  <circle cx="32" cy="32" r="3" fill="#fbbf24" />
                </svg>
              </span>
              <span className="flex flex-col leading-none">
                <span className="font-display text-lg font-bold text-white">Simtrix</span>
                <span className="text-[10px] font-medium uppercase tracking-[0.2em] text-ink-500">Infotech</span>
              </span>
            </Link>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-ink-400">
              {company.description}
            </p>

            <div className="mt-6 flex items-center gap-3">
              {[Linkedin, Twitter, Facebook, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social link"
                  className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 text-ink-400 ring-1 ring-white/10 transition-all hover:bg-brand-600 hover:text-white hover:ring-brand-500"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div className="lg:col-span-3">
            <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">Services</h4>
            <ul className="mt-5 space-y-3 text-sm">
              {footerNav.services.map((s) => (
                <li key={s.label}>
                  <Link to={s.href} className="text-ink-400 transition-colors hover:text-brand-300">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Solutions */}
          <div className="lg:col-span-2">
            <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">Solutions</h4>
            <ul className="mt-5 space-y-3 text-sm">
              {footerNav.solutions.map((s) => (
                <li key={s.label}>
                  <Link to={s.href} className="text-ink-400 transition-colors hover:text-brand-300">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company + Contact */}
          <div className="col-span-2 lg:col-span-3">
            <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-white">Company</h4>
            <ul className="mt-5 space-y-3 text-sm">
              {footerNav.company.map((s) => (
                <li key={s.label}>
                  <Link to={s.href} className="text-ink-400 transition-colors hover:text-brand-300">
                    {s.label}
                  </Link>
                </li>
              ))}
            </ul>

            <div className="mt-6 space-y-3 text-sm">
              <a href={company.phoneHref} className="flex items-start gap-3 text-ink-400 transition-colors hover:text-brand-300">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                {company.phone}
              </a>
              <a href={company.emailHref} className="flex items-start gap-3 text-ink-400 transition-colors hover:text-brand-300">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                {company.email}
              </a>
              <p className="flex items-start gap-3 text-ink-400">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-400" />
                <span>
                  {company.address.line1}, {company.address.line3}, {company.address.line4}, {company.address.city} - {company.address.pincode}
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/10 py-6 text-xs text-ink-500 sm:flex-row">
          <p>© {year} {company.name}. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link to="/company" className="transition-colors hover:text-ink-300">Privacy Policy</Link>
            <Link to="/company" className="transition-colors hover:text-ink-300">Terms of Service</Link>
            <span className="hidden sm:inline">Designed in New Delhi, India</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
