import { Phone, Mail, MapPin, Clock, ChevronRight } from 'lucide-react';
import { company } from '@/data/company';

export function TopBar() {
  return (
    <div className="hidden bg-ink-950 text-ink-300 lg:block">
      <div className="container-page flex h-10 items-center justify-between text-xs">
        <div className="flex items-center gap-6">
          <a href={company.phoneHref} className="flex items-center gap-1.5 transition-colors hover:text-white">
            <Phone className="h-3.5 w-3.5 text-brand-400" />
            {company.phone}
          </a>
          <a href={company.emailHref} className="flex items-center gap-1.5 transition-colors hover:text-white">
            <Mail className="h-3.5 w-3.5 text-brand-400" />
            {company.email}
          </a>
          <span className="hidden items-center gap-1.5 xl:flex">
            <MapPin className="h-3.5 w-3.5 text-brand-400" />
            Swasthya Vihar, New Delhi
          </span>
        </div>
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-brand-400" />
            {company.hours}
          </span>
          <span className="flex items-center gap-1 text-ink-500">
            <ChevronRight className="h-3 w-3" />
            Engineering Smart Buildings Across India
          </span>
        </div>
      </div>
    </div>
  );
}
